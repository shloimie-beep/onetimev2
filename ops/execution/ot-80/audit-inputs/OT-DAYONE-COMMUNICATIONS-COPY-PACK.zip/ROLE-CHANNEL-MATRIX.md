# Role–Channel Matrix

Package version: `1.0.0`

Legend:

- **Allowed** — available only after the message-specific committed-state, consent, suppression and idempotency checks pass.
- **Conditional** — available for a narrow purpose stated in the notes.
- **Not permitted** — this package does not authorize the role/channel combination.
- **Reference only** — copy may exist for future review, but the channel is not activated.

## Matrix

| Audience or role | Public web | Email | Consented WhatsApp | Secure in-app / protected application | Secure operator inbox / internal email | SMS |
|---|---|---|---|---|---|---|
| Public Family signup contact | Allowed for committed success page | Conditional: immediate acknowledgement after policy approval | Conditional: immediate acknowledgement only with affirmative WhatsApp consent | Not permitted until a separate entitlement/account state is committed | Not applicable as recipient | Reference only; not activated |
| School lead | Allowed for committed School acknowledgement | Not permitted for automated Family, class, reminder or portal messages; later human follow-up requires separate approval | Not permitted for automated Family, class, reminder or portal messages; later human follow-up requires separate approval | Not permitted | Internal owner/admin alert is permitted, but the School lead is not the recipient | Not permitted |
| Entitled parent or Family recipient | Public holding/status pages when appropriate | Allowed for approved acknowledgements, reminders, account, security and support notices | Conditional: only approved acknowledgements/reminders with purpose-specific consent | Allowed after entitlement and authorization are committed | Not applicable as recipient | Reference only; not activated |
| Parent account holder | Public Member Login holding page while activation is unavailable | Allowed for activation, student-access, reset, security and support copy | Not permitted for account/security recovery in this package | Allowed for parent account and authorized student-management actions | Not applicable as recipient | Not permitted |
| Student account holder | Public Member Login holding page while activation is unavailable | Conditional: password-reset/security notice only when the student contact route is approved | Not permitted in this package | Allowed through a separate student account | Not applicable as recipient | Not permitted |
| Owner — Rabbi Eli Scheller | Public pages as an ordinary visitor | Conditional: verified internal operational/security route | Not permitted by default | Allowed under owner authorization | Allowed for protected lead, suppression and security alerts | Not permitted |
| Administrator — Shloimie | Public pages as an ordinary visitor | Conditional: verified internal operational/security route | Not permitted by default | Allowed under administrator authorization | Allowed for protected lead, suppression and security alerts | Not permitted |
| Authorized operator/support staff | Public pages as an ordinary visitor | Conditional only when an approved internal route and role require it | Not permitted by default | Allowed to the minimum scope required by role | Allowed for protected operational statuses | Not permitted |
| Support requester | Public support entry/status pages only when available | Allowed for opened, updated and resolved confirmations | Not permitted in this package | Allowed for protected ticket content | Not applicable as recipient | Not permitted |
| Unauthenticated Member Login visitor | Allowed for the holding page | No email is created by page view alone | Not permitted | Not permitted until account/activation state permits it | Not applicable | Not permitted |

## Non-negotiable role boundaries

### Family versus School

A Family signup and a School signup are different committed record types and different lifecycles. A School lead is human-follow-up-only. It must never be promoted into a Family acknowledgement, class reminder, class link, portal entitlement or member-account message by channel fallback, list import, deduplication or operator convenience.

### Parent versus student

Parent and student accounts are separate principals. A parent may be authorized to reset or suspend student access. No parent-facing copy or interface may expose, retrieve or imply access to the student’s current password or secret.

### Owner and administrator identity

Rabbi Eli Scheller is the owner. Shloimie is the administrator. Internal system notices may be routed to their verified roles, but copy must not say or imply that either person personally wrote, sent, approved or performed an action unless the underlying audit record proves that specific action and a separate approved template exists.

## Channel fallback

A failed or suppressed channel does not authorize another channel. In particular:

- missing or revoked WhatsApp consent does not authorize SMS;
- an email hard bounce does not authorize WhatsApp;
- provider delay does not authorize a raw provider link;
- an internal alert failure does not authorize placing lead contact details in a personal message;
- a School lead restriction cannot be bypassed by sending “just the Family acknowledgement.”

## Timing

The daily live class begins at **7:00 p.m. Asia/Jerusalem**. T-30 reminder evaluation occurs at **6:30 p.m. Asia/Jerusalem**. A reminder is still conditional on session readiness, recipient entitlement, channel policy, suppression and a committed protected application link.
