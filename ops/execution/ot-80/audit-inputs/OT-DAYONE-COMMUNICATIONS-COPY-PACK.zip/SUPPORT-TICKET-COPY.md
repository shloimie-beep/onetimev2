# Support Ticket Copy

Package version: `1.0.0`

This file covers support-ticket opened, updated and resolved confirmations. `MESSAGE-CATALOG.json` remains authoritative.

## Shared support rules

- The support ticket, update or resolution must commit before a confirmation is created.
- External copy contains only the non-PII `${ticket_reference}`.
- Ticket content, attachments, private notes and sensitive summaries remain behind `${protected_ticket_url}`.
- Email and secure in-app are the only approved support-confirmation channels in this package.
- WhatsApp and SMS are not authorized for these confirmations.
- No template promises an initial response time, resolution time or service level.
- A broken or missing protected ticket link blocks the linked email notice but never rolls back the ticket/update/resolution.
- Each committed event has its own idempotency key and audit event.

## Ticket opened

**Message key:** `support.ticket.opened`  
**Version:** `1.0.0`  
**Audit event:** `communications.support_ticket_opened_sent`

**Subject**

```text
Support request ${ticket_reference} received
```

**Title**

```text
Support request received
```

**Body**

```text
We received your support request ${ticket_reference}. Our team will review it. Use the secure ticket page to see updates.
```

**CTA**

```text
View support request
```

Target: `${protected_ticket_url}`

### Trigger and required state

- `support_ticket.status = open`
- ticket reference committed
- protected ticket-view link committed
- email policy decision allowed
- opened-notice intent committed

### Fallback

Keep the ticket open and visible in the protected support system. Do not copy ticket details into external email and do not invent a response-time commitment.

## Ticket updated

**Message key:** `support.ticket.updated`  
**Version:** `1.0.0`  
**Audit event:** `communications.support_ticket_updated_sent`

**Subject**

```text
Support request ${ticket_reference} updated
```

**Title**

```text
Support request updated
```

**Body**

```text
There is an update on support request ${ticket_reference}. Use the secure ticket page to read the latest message.
```

**CTA**

```text
View update
```

Target: `${protected_ticket_url}`

### Trigger and required state

- the support update is committed;
- the ticket remains in a valid lifecycle state;
- the protected ticket-view link is committed;
- email policy is allowed;
- the update-notice intent is committed.

### Fallback

Keep the update in the protected ticket. Do not paste the update text, private notes or attachments into the external notification. A provider retry must reuse the same logical intent.

## Ticket resolved

**Message key:** `support.ticket.resolved`  
**Version:** `1.0.0`  
**Audit event:** `communications.support_ticket_resolved_sent`

**Subject**

```text
Support request ${ticket_reference} resolved
```

**Title**

```text
Support request resolved
```

**Body**

```text
Support request ${ticket_reference} has been marked resolved. Review the resolution on the secure ticket page. If the issue is not resolved for you, use the official support path to tell us.
```

**CTA**

```text
Review resolution
```

Target: `${protected_ticket_url}`

### Trigger and required state

- `support_ticket.status = resolved`
- the resolution event is committed;
- the protected ticket-view link is committed;
- email policy is allowed;
- the resolved-notice intent is committed.

### Fallback

Keep the resolution visible in the protected support system. Do not claim that the requester agreed with the resolution. Do not promise a reopen feature; the copy directs the requester to the official support path.

## Idempotency

| Message key | Logical uniqueness |
|---|---|
| `support.ticket.opened` | One successful confirmation per support ticket, key and version |
| `support.ticket.updated` | One successful notice per committed support update, key and version |
| `support.ticket.resolved` | One successful notice per committed resolution event, key and version |

Delivery retries reuse the existing outbound intent. A template version change does not authorize replaying historical ticket events.

## Consent and suppression

Support confirmations are transactional correspondence under the organization’s approved policy basis. Apply legal, complaint, hard-bounce and global safety suppressions. Do not fall back to WhatsApp or SMS. When an email cannot be sent, the protected in-app ticket remains the source of truth.

## Data handling

Allowed in external copy:

- `${ticket_reference}`;
- generic lifecycle state: received, updated or resolved;
- protected CTA label and protected application URL.

Prohibited in external copy:

- requester email or phone number;
- ticket description, support-agent response, private note or attachment;
- password, token, credential or account secret;
- raw provider/admin URL;
- provider name, identifier or raw error;
- an invented response or resolution time.

## Provider or protected-link delay

If `${protected_ticket_url}` is unavailable, do not send a broken email. Keep the committed support record in-app and create a delivery-delay status. The generic `communications.secure_access_delayed` copy may be used only if the selected external channel is independently allowed and the wording is accurate for the current state.
