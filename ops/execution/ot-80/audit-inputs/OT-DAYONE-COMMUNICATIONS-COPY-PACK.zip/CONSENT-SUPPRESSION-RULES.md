# Consent and Suppression Rules

Package version: `1.0.0`

These rules govern whether approved copy may be rendered or sent. They do not establish a jurisdiction-specific legal basis; unresolved legal and business choices are listed in `DECISIONS-NEEDED.md`.

## Required evaluation order

For every outbound intent, evaluate in this order:

1. **Committed business state** — the lead, account, class session, security event, support event or other triggering record must already be committed.
2. **Role eligibility** — confirm that the recipient role is allowed for the message key. A School lead fails every Family, class, reminder and portal-message eligibility check.
3. **Purpose and channel eligibility** — confirm that the selected channel is allowed for this message key and purpose.
4. **Consent evidence** — where consent is required, verify its current status, scope, source, timestamp and policy version.
5. **Suppression controls** — apply channel opt-outs, revocations, complaints, hard bounces, global do-not-contact controls, legal blocks and safety restrictions.
6. **Readiness and protected-link checks** — confirm that every required protected application link exists and the advertised feature is actually ready.
7. **Idempotency claim** — atomically claim the message’s idempotency key before dispatch.
8. **Dispatch attempt** — call the approved delivery path only after all prior checks pass.
9. **Audit** — record the decision and outcome using non-PII references. Never record a complete protected link, password, token, phone number or email address in an audit event name.

A provider must never be consulted to decide whether a public Family or School signup itself commits. Signup commit comes first and remains valid if a provider is unavailable.

## Consent rules by purpose

### Public pages

Public success, acknowledgement and holding pages do not require messaging consent. A page view does not create permission to send email, WhatsApp or SMS.

### Immediate Family email acknowledgement

The Family email acknowledgement may be evaluated only after the Family lead/contact commits. It must use the organization’s approved transactional-email basis and must respect all applicable legal, complaint, hard-bounce and global safety suppressions.

The final decision about how transactional email interacts with marketing opt-out preferences is unresolved and is listed in `DECISIONS-NEEDED.md`. Until resolved, implementation must keep marketing permission and transactional eligibility as separate fields.

### Immediate Family WhatsApp acknowledgement

WhatsApp requires affirmative, current consent for WhatsApp and for the relevant acknowledgement purpose. A phone number alone is not consent. Pre-checked consent, inferred consent, consent copied from another channel and stale or unverifiable consent are not sufficient.

If consent is absent, revoked or uncertain:

- do not send;
- do not switch to SMS;
- do not ask an operator to copy the number into a personal device;
- evaluate email separately only when email has an independent allowed basis.

### Class reminders

A class reminder requires all of the following:

- a committed class session beginning at 7:00 p.m. Asia/Jerusalem;
- the T-30 evaluation at 6:30 p.m. Asia/Jerusalem;
- an eligible, entitled recipient;
- a channel-specific allowed purpose;
- no applicable suppression;
- a committed protected application join link.

A School lead is never eligible. A missing protected link is a readiness delay, not permission to expose a raw class/provider URL.

WhatsApp reminder consent must cover reminders, not merely the initial acknowledgement. Whether one consent statement may cover both purposes is an unresolved decision.

### Account, password and security messages

Account activation, password-reset and security notices use only approved account/security routes. This package does not authorize recovery by WhatsApp or SMS. Security notifications may be subject to specialized legal/safety handling, but they must never reveal credentials, recovery codes, factors, tokens or account-existence details.

### Support messages

Support confirmations are limited to email and secure in-app delivery in this package. They contain only a non-PII ticket reference and direct the requester to the protected ticket. They must not include ticket content, private notes or attachments in external copy.

### Internal owner, administrator and operator alerts

Internal alerts are governed by role-based access control rather than the external lead’s marketing preferences. They must be minimal, protected and routed only to verified roles. External suppression does not permit an operator to bypass a blocked message; it is precisely why the internal message-not-sent status exists.

## Suppression reason taxonomy

Only allowlisted labels may be rendered in `${suppression_reason_label}`.

| Label | Meaning | Required action |
|---|---|---|
| `whatsapp_consent_missing` | No affirmative WhatsApp consent is on record | Do not send WhatsApp; do not switch to SMS |
| `whatsapp_consent_revoked` | WhatsApp consent was withdrawn | Do not send WhatsApp until a new valid consent record exists |
| `channel_opt_out` | Recipient opted out of the selected channel/purpose | Do not send on that channel/purpose |
| `hard_bounce` | The address is known to be undeliverable | Suppress further email attempts until corrected under approved policy |
| `complaint` | A complaint or abuse signal blocks the channel | Do not send; escalate only through approved compliance handling |
| `global_do_not_contact` | A broad contact restriction applies | Do not send externally unless a separately documented legal/safety exception is approved |
| `role_not_eligible` | Recipient role does not match the message | Do not send; correct routing data rather than changing copy |
| `school_lead_restriction` | A School lead was selected for prohibited Family/class/account copy | Do not send; preserve the School human-follow-up-only lifecycle |
| `duplicate_intent` | The idempotency claim already exists | Do not send a duplicate |

Raw provider errors, exception messages and contact details are not suppression labels.

## Readiness delays versus suppression

A message blocked because a required protected link or feature is not ready is a **readiness delay**, not evidence of missing consent. Preserve the consent decision separately.

For readiness delays:

- keep the underlying business record committed;
- do not claim that the feature is ready;
- do not substitute a raw provider, meeting or admin URL;
- use `communications.secure_access_delayed` only on a channel that independently remains allowed and available;
- retry only under an approved retry policy;
- prevent repeated delay notices with a delay-window idempotency key.

## Channel fallback policy

Channel fallback is opt-in, not automatic. A fallback channel may be evaluated only when:

1. that channel is listed as allowed for the message key;
2. its own purpose/consent requirements are satisfied;
3. it has no applicable suppression;
4. the copy is approved for that channel;
5. the new send has its own idempotency claim.

This package never authorizes SMS. SMS-length alternatives are reference-only.

## Idempotency model

Each outbound record should have a deterministic key composed from:

- stable message key;
- message version;
- committed triggering object reference;
- recipient reference;
- event/session reference where applicable;
- channel;
- delay window or update reference where applicable.

The claim must be atomic. Provider retries reuse the same committed outbound intent and must not create a new logical send. A content version change creates a new template version but does not by itself authorize resending an old business event.

## Retry categories

| Outcome | Retry posture |
|---|---|
| Consent missing, revoked, opt-out, complaint, global block, wrong role, School restriction | No automatic retry |
| Duplicate intent | No retry; treat as already handled |
| Hard bounce | No automatic retry until the address is corrected under approved policy |
| Temporary delivery failure after all policy checks pass | Retry the same intent under capped backoff and provider-independent idempotency |
| Required protected link missing | Delay; retry link creation under the approved readiness policy |
| Public page render failure | Application reliability incident; never replace a committed signup with an error that implies the record was not saved |

Exact retry counts, windows and escalation thresholds remain unresolved.

## Audit and data minimization

Record:

- message key and version;
- non-PII triggering record and recipient references;
- role;
- channel;
- consent/policy decision reference;
- suppression label, if any;
- idempotency key reference;
- dispatch outcome;
- event timestamp.

Do not record:

- full email addresses or phone numbers in event names;
- complete protected URLs;
- class/provider URLs or provider identifiers;
- passwords, secrets, tokens or recovery codes;
- message body copies containing unnecessary personal data;
- price or payment data not explicitly approved.

## Operator no-send behavior

When a policy rule blocks a committed intent, create `communications.message_not_sent.operator_status`. The operator copy must state that no message was sent, identify the stable message key and a non-PII recipient reference, show an allowlisted reason, and explicitly prohibit bypassing the decision through another channel.

The committed lead, account, ticket or other business record remains unchanged.
