# Message Copy

Package version: `1.0.0`  
Prepared: `2026-07-15`

This is the human-readable companion to `MESSAGE-CATALOG.json`. The copy in fenced blocks is exact. Runtime variables use the neutral `${variable_name}` syntax and are defined in `VARIABLE-DICTIONARY.md`.

The catalog contains 19 stable message records covering the 16 requested communication items. Item 11 has request and completion variants; item 14 has opened, updated and resolved variants.


## Item 1 — `family.signup.success_page`

**Version:** `1.0.0`  

**Audience/role:** `public_family_signup_contact`  

**Allowed channel:** `public_web`  

**Protected link required:** No


### Trigger and committed state

**Trigger:** Render only after the Family signup transaction returns a committed Family lead and committed contact.

- family_lead.status = committed
- family_contact.status = committed
- deduplication decision persisted
- page render does not depend on email, WhatsApp, class, payment or other provider availability


### Exact copy

**Subject:** Not applicable.


**Title:**

```text
Thank you — we received your Family signup.
```


**Heading:** Same exact copy as the title.


**Body:**

```text
Your information has been saved. You may receive an acknowledgement by email and, only if you consented, by WhatsApp. Class access and member login details are sent separately when they are ready.
```


**CTA label:** `Return to One Time One Time`  
**CTA target:** `${transition_home_url}`  
**CTA fallback:** Omit the CTA if the allowlisted transition URL is unavailable; keep the success copy visible.


### Variables and safe fallback

- `${transition_home_url}` — optional; fallback: Render the page without a CTA.


**Overall safe fallback:** Always render the committed-success copy even when every communications provider is unavailable. Do not roll back or obscure the committed lead/contact.


### Consent, suppression and delivery policy

- The page itself requires no messaging consent.
- Do not infer WhatsApp consent from the presence of a phone number.
- Do not create a School lead or send School copy from this state.


**Idempotency:** Repeated renders for the same committed Family signup are side-effect free and must not create additional lead, contact or outbound-message records.


**Audit event:** `family.signup_success_rendered`


### Prohibited claims or data

- A claim that class access, portal access, an account or payment is active.
- A price, charge, subscription or Stripe object.
- A raw class, meeting or provider URL.


---

## Item 2 — `family.ack.email`

**Version:** `1.0.0`  

**Audience/role:** `family_contact`  

**Allowed channel:** `email`  

**Protected link required:** No


### Trigger and committed state

**Trigger:** Queue after the Family lead/contact transaction commits and email policy evaluation returns allowed.

- family_lead.status = committed
- family_contact.status = committed
- recipient email reference validated
- email policy decision = allowed
- outbox intent committed before dispatch


### Exact copy

**Subject:**

```text
We received your Family signup
```


**Title:** Not applicable.


**Body:**

```text
Hi ${family_contact_first_name},

Thank you for signing up for One Time One Time with Rabbi Eli Scheller. Your Family signup has been saved.

This message confirms receipt only. Class access and member login details will be sent separately when they are ready.

— One Time One Time
```


**CTA label:** `Visit One Time One Time`  
**CTA target:** `${transition_home_url}`  
**CTA fallback:** Omit the CTA; the acknowledgement remains complete without it.


### Variables and safe fallback

- `${family_contact_first_name}` — optional; fallback: Replace the opening line with “Hello,”.

- `${transition_home_url}` — optional; fallback: Omit the CTA.


**Overall safe fallback:** If email is suppressed or unavailable, do not undo the signup and do not silently switch channels. Create the consent/suppression-safe operator status. A separately consented WhatsApp acknowledgement may still be evaluated on its own merits.


### Consent, suppression and delivery policy

- Send only under the approved transactional-email basis for the committed signup.
- Honor applicable email suppression, complaint, hard-bounce and do-not-contact controls.
- Marketing permission must not be treated as the sole basis for this transactional copy.
- Never send this Family message to a School lead.


**Idempotency:** At most one successful send per family_signup_reference, message_key and version.


**Audit event:** `communications.family_ack_email_sent`


### Prohibited claims or data

- A class link, portal entitlement or account-ready claim.
- A price, charge or payment confirmation.
- A raw recipient address in logs, subject lines or audit labels.


---

## Item 3 — `family.ack.whatsapp`

**Version:** `1.0.0`  

**Audience/role:** `family_contact`  

**Allowed channel:** `whatsapp_consented`  

**Protected link required:** No


### Trigger and committed state

**Trigger:** Queue after the Family lead/contact transaction commits and affirmative WhatsApp consent is verified.

- family_lead.status = committed
- family_contact.status = committed
- WhatsApp consent status = granted
- WhatsApp consent evidence persisted
- channel suppression decision = allowed
- outbox intent committed before dispatch


### Exact copy

**Subject:** Not applicable.


**Title:** Not applicable.


**Body:**

```text
Hi ${family_contact_first_name} — we received your Family signup for One Time One Time with Rabbi Eli Scheller. This confirms receipt only. Class access and member login details are sent separately when ready.
```


**CTA label:** `Open One Time One Time`  
**CTA target:** `${transition_home_url}`  
**CTA fallback:** Send the acknowledgement without a CTA only when the WhatsApp channel remains allowed.


### Variables and safe fallback

- `${family_contact_first_name}` — optional; fallback: Replace “Hi ${family_contact_first_name}” with “Hello”.

- `${transition_home_url}` — optional; fallback: Omit the CTA.


**Overall safe fallback:** If affirmative WhatsApp consent is absent, revoked or uncertain, do not send. Do not switch to SMS. Evaluate email separately only when email is independently allowed.


### Consent, suppression and delivery policy

- A supplied phone number is not consent.
- Consent must cover WhatsApp and the acknowledgement purpose.
- Honor revocation, channel opt-out, block and global do-not-contact status.
- Never send this Family message to a School lead.


**Idempotency:** At most one successful send per family_signup_reference, message_key and version.


**Audit event:** `communications.family_ack_whatsapp_sent`


### Prohibited claims or data

- A class link, portal entitlement or account-ready claim.
- A raw phone number in copy, logs or audit labels.
- A fallback to SMS without separate authorization.


---

## Item 4 — `class.reminder.t30.email`

**Version:** `1.0.0`  

**Audience/role:** `entitled_parent_or_family_recipient`  

**Allowed channel:** `email`  

**Protected link required:** Yes


### Trigger and committed state

**Trigger:** Evaluate at 6:30 p.m. Asia/Jerusalem for the daily 7:00 p.m. Asia/Jerusalem live class.

- class_session.status = committed
- class_session.start_time = 7:00 p.m. Asia/Jerusalem
- recipient role is eligible and not School lead
- recipient class entitlement = active
- email reminder policy decision = allowed
- protected application join link committed
- T-30 reminder intent committed


### Exact copy

**Subject:**

```text
Live class starts at 7:00 p.m. Jerusalem time
```


**Title:** Not applicable.


**Body:**

```text
Hi ${recipient_first_name},

Tonight’s live class with Rabbi Eli Scheller starts at 7:00 p.m. Asia/Jerusalem. Use the secure button below to open the class page. Please do not forward the link.

— One Time One Time
```


**CTA label:** `Open secure class page`  
**CTA target:** `${protected_join_url}`  
**CTA fallback:** Do not send the reminder without the protected application link.


### Variables and safe fallback

- `${recipient_first_name}` — optional; fallback: Replace the opening line with “Hello,”.

- `${protected_join_url}` — required; fallback: Do not send; record a delivery-delay state.


**Overall safe fallback:** When the protected link is unavailable at T-30, do not expose a raw class/provider URL. Mark the reminder delayed and use the approved provider-unavailable/delayed copy only on an independently available, consented channel.


### Consent, suppression and delivery policy

- Never send to a School lead.
- Send only to an entitled recipient whose email reminder purpose is allowed.
- Honor email suppression, complaint, hard-bounce and do-not-contact controls.
- Do not infer WhatsApp or SMS permission from email eligibility.


**Idempotency:** At most one successful email reminder per recipient_reference, class_session_reference, message_key and version.


**Audit event:** `communications.class_reminder_t30_email_sent`


### Prohibited claims or data

- A raw Zoom, meeting, class or provider URL.
- A claim that access is ready when the protected link is absent.
- A School lead recipient.
- A price, charge or payment prompt.


### SMS-length alternative — reference only

SMS is not an allowed channel in this package. This copy is retained only for future policy review.

```text
One Time One Time: class starts at 7:00 p.m. Jerusalem time. Secure access: ${protected_join_url}
```


### Notes

- The SMS-length alternative is reference copy only. SMS is not an allowed channel in this package.


---

## Item 5 — `class.reminder.t30.whatsapp`

**Version:** `1.0.0`  

**Audience/role:** `entitled_parent_or_family_recipient`  

**Allowed channel:** `whatsapp_consented`  

**Protected link required:** Yes


### Trigger and committed state

**Trigger:** Evaluate at 6:30 p.m. Asia/Jerusalem for the daily 7:00 p.m. Asia/Jerusalem live class.

- class_session.status = committed
- class_session.start_time = 7:00 p.m. Asia/Jerusalem
- recipient role is eligible and not School lead
- recipient class entitlement = active
- WhatsApp reminder consent = granted
- channel suppression decision = allowed
- protected application join link committed
- T-30 reminder intent committed


### Exact copy

**Subject:** Not applicable.


**Title:** Not applicable.


**Body:**

```text
Reminder: tonight’s live class with Rabbi Eli Scheller starts at 7:00 p.m. Asia/Jerusalem. Open the secure class page below. Please do not forward the link.
```


**CTA label:** `Open secure class page`  
**CTA target:** `${protected_join_url}`  
**CTA fallback:** Do not send the reminder without the protected application link.


### Variables and safe fallback

- `${protected_join_url}` — required; fallback: Do not send; record a delivery-delay state.


**Overall safe fallback:** When consent is missing or the protected link is unavailable, do not send and do not substitute a raw provider URL or SMS. Evaluate an email reminder separately only when email is independently allowed.


### Consent, suppression and delivery policy

- Affirmative WhatsApp consent must cover reminders.
- Honor revocation, channel opt-out, block and global do-not-contact status.
- Never send to a School lead.
- Do not use a phone number merely because it was supplied on signup.


**Idempotency:** At most one successful WhatsApp reminder per recipient_reference, class_session_reference, message_key and version.


**Audit event:** `communications.class_reminder_t30_whatsapp_sent`


### Prohibited claims or data

- A raw Zoom, meeting, class or provider URL.
- A claim that access is ready when the protected link is absent.
- A School lead recipient.
- A fallback to SMS without separate authorization.


---

## Item 6 — `school.signup.public_ack`

**Version:** `1.0.0`  

**Audience/role:** `public_school_signup_contact`  

**Allowed channel:** `public_web`  

**Protected link required:** No


### Trigger and committed state

**Trigger:** Render only after the School lead transaction commits.

- school_lead.status = committed
- deduplication decision persisted
- no Family contact, class entitlement or portal entitlement created from this trigger


### Exact copy

**Subject:** Not applicable.


**Title:**

```text
Thank you — we received your school inquiry.
```


**Heading:** Same exact copy as the title.


**Body:**

```text
A member of the One Time One Time team will review it and follow up personally. This inquiry does not create class access, reminders, a portal account, or Family messages.
```


**CTA label:** `Return to One Time One Time`  
**CTA target:** `${transition_home_url}`  
**CTA fallback:** Omit the CTA if the allowlisted transition URL is unavailable.


### Variables and safe fallback

- `${transition_home_url}` — optional; fallback: Render the page without a CTA.


**Overall safe fallback:** Render the acknowledgement without any provider dependency. If human follow-up routing is unavailable, retain the committed School lead and raise an internal operational status; do not send automated Family copy.


### Consent, suppression and delivery policy

- The public acknowledgement itself requires no outbound-message consent.
- Any later human follow-up must use an independently approved channel and policy basis.
- A School lead must never receive a class link, reminder, portal entitlement or Family message.


**Idempotency:** Repeated renders for the same committed School lead are side-effect free and must not create entitlements or automated outbound messages.


**Audit event:** `school.signup_public_ack_rendered`


### Prohibited claims or data

- A class link, reminder, portal entitlement or Family acknowledgement.
- A claim that a school account or class is active.
- An automated follow-up promise or response-time promise.


---

## Item 7 — `owner.alert.family_lead`

**Version:** `1.0.0`  

**Audience/role:** `owner_rabbi_scheller`, `administrator_shloimie`  

**Allowed channel:** `secure_operator_inbox`, `internal_email`  

**Protected link required:** Yes


### Trigger and committed state

**Trigger:** Create after a new Family lead/contact is committed and internal alert routing is authorized.

- family_lead.status = committed
- family_contact.status = committed
- internal recipient role verified
- protected lead-record link committed
- internal alert intent committed


### Exact copy

**Subject:**

```text
New Family lead received
```


**Title:**

```text
New Family lead received
```


**Body:**

```text
A new Family lead was committed successfully.

Reference: ${lead_reference}
Received: ${submitted_at_local}

Review the protected record for contact details, consent status and follow-up notes.
```


**CTA label:** `Review Family lead`  
**CTA target:** `${protected_lead_url}`  
**CTA fallback:** Do not send the alert without the protected lead-record link.


### Variables and safe fallback

- `${lead_reference}` — required; fallback: Do not send; the internal alert must retain a non-PII record reference.

- `${submitted_at_local}` — required; fallback: Do not send; the event time is required for operational triage.

- `${protected_lead_url}` — required; fallback: Do not send; raise an internal delivery-delay status.


**Overall safe fallback:** Keep the lead committed. If protected internal delivery is unavailable, create a secure operational status without copying contact details into an unprotected channel.


### Consent, suppression and delivery policy

- This is a minimal internal operational alert, not a message to the lead.
- External marketing preferences do not authorize or prohibit the internal alert; internal access control does.
- Send only to verified privileged recipients under routing approved for Rabbi Scheller and Shloimie.


**Idempotency:** At most one successful internal alert per family_lead_reference, message_key and version.


**Audit event:** `communications.owner_family_lead_alert_sent`


### Prohibited claims or data

- Full contact details or raw form payload in the subject/body.
- Language implying the message was personally written or sent by Rabbi Scheller or Shloimie.
- A raw admin, provider or class URL.


---

## Item 8 — `owner.alert.school_lead`

**Version:** `1.0.0`  

**Audience/role:** `owner_rabbi_scheller`, `administrator_shloimie`  

**Allowed channel:** `secure_operator_inbox`, `internal_email`  

**Protected link required:** Yes


### Trigger and committed state

**Trigger:** Create after a new School lead is committed and internal alert routing is authorized.

- school_lead.status = committed
- internal recipient role verified
- protected lead-record link committed
- internal alert intent committed


### Exact copy

**Subject:**

```text
New School lead received
```


**Title:**

```text
New School lead received
```


**Body:**

```text
A new School lead was committed successfully.

Reference: ${lead_reference}
Received: ${submitted_at_local}

School leads require human follow-up only. Do not send class links, reminders, portal access or Family messages.
```


**CTA label:** `Review School lead`  
**CTA target:** `${protected_lead_url}`  
**CTA fallback:** Do not send the alert without the protected lead-record link.


### Variables and safe fallback

- `${lead_reference}` — required; fallback: Do not send; the internal alert must retain a non-PII record reference.

- `${submitted_at_local}` — required; fallback: Do not send; the event time is required for operational triage.

- `${protected_lead_url}` — required; fallback: Do not send; raise an internal delivery-delay status.


**Overall safe fallback:** Keep the School lead committed. If protected internal delivery is unavailable, create a secure operational status. Never replace the alert with an automated message to the School lead.


### Consent, suppression and delivery policy

- This is a minimal internal operational alert, not a message to the School lead.
- Send only to verified privileged recipients under approved internal routing.
- The School lead remains in a human-follow-up-only lifecycle.


**Idempotency:** At most one successful internal alert per school_lead_reference, message_key and version.


**Audit event:** `communications.owner_school_lead_alert_sent`


### Prohibited claims or data

- Full contact details or raw form payload in the subject/body.
- Language implying the message was personally written or sent by Rabbi Scheller or Shloimie.
- Any automated class, reminder, portal or Family message to the School lead.


---

## Item 9 — `account.parent.invitation`

**Version:** `1.0.0`  

**Audience/role:** `parent_account_holder`  

**Allowed channel:** `email`  

**Protected link required:** Yes


### Trigger and committed state

**Trigger:** Send only after the parent account and a protected activation action are committed and ready.

- parent_account.status = activation_ready
- parent identity/contact relationship verified
- protected activation action committed
- email policy decision = allowed
- invitation intent committed


### Exact copy

**Subject:**

```text
Activate your One Time One Time parent account
```


**Title:** Not applicable.


**Body:**

```text
Hi ${parent_first_name},

Your parent account is ready to activate. Use the secure link below to choose your password. This link is for you and may expire.

Parent and student accounts are separate. A parent can reset or suspend student access, but cannot view the student’s current password.

— One Time One Time
```


**CTA label:** `Activate parent account`  
**CTA target:** `${protected_parent_activation_url}`  
**CTA fallback:** Do not send the invitation without a valid protected activation link.


### Variables and safe fallback

- `${parent_first_name}` — optional; fallback: Replace the opening line with “Hello,”.

- `${protected_parent_activation_url}` — required; fallback: Do not send; keep the account in activation-ready state and record a delivery delay.


**Overall safe fallback:** If account activation is not actually ready, do not send this invitation. Direct unauthenticated users to the approved Member Login holding page instead.


### Consent, suppression and delivery policy

- Treat as account/security transactional email under the approved policy basis.
- Honor legal, complaint, hard-bounce and global safety suppressions.
- Do not send to a School lead or to a student address as a substitute for the parent.


**Idempotency:** At most one successful send per parent_activation_action_reference, message_key and version.


**Audit event:** `communications.parent_invitation_sent`


### Prohibited claims or data

- A password, activation token or credential in message copy.
- A claim that the student account shares the parent account.
- A way for a parent to retrieve the student’s current password.
- A price or charge.


---

## Item 10 — `account.student_access_ready.parent_notice`

**Version:** `1.0.0`  

**Audience/role:** `authorized_parent_account_holder`  

**Allowed channel:** `email`  

**Protected link required:** Yes


### Trigger and committed state

**Trigger:** Send after student access is committed as ready and the parent relationship is authorized.

- student_account.status = access_ready
- parent_account.status = active
- parent_student_relationship.status = authorized
- protected student-management link committed
- email policy decision = allowed
- notice intent committed


### Exact copy

**Subject:**

```text
Student access is ready
```


**Title:** Not applicable.


**Body:**

```text
Hi ${parent_first_name},

Student access is ready for ${student_display_name}. Parent and student accounts are separate.

For security, the student’s current password cannot be viewed. From your parent account, you can reset or suspend the student’s access when needed.

— One Time One Time
```


**CTA label:** `Manage student access`  
**CTA target:** `${protected_student_management_url}`  
**CTA fallback:** Do not send the notice without a protected parent-side management link.


### Variables and safe fallback

- `${parent_first_name}` — optional; fallback: Replace the opening line with “Hello,”.

- `${student_display_name}` — optional; fallback: Replace with “your student”.

- `${protected_student_management_url}` — required; fallback: Do not send; record a delivery delay.


**Overall safe fallback:** Do not send until both the student access state and parent authorization are committed. Never include the student’s current password or a credential-recovery shortcut.


### Consent, suppression and delivery policy

- Treat as account/security transactional email under the approved policy basis.
- Honor legal, complaint, hard-bounce and global safety suppressions.
- Send only to the authorized parent relationship, never to a School lead.


**Idempotency:** At most one successful notice per student_access_ready_event_reference, authorized_parent_reference, message_key and version.


**Audit event:** `communications.student_access_ready_parent_notice_sent`


### Prohibited claims or data

- The student’s current password, secret, token or credential.
- A claim that parent and student accounts are the same.
- A direct class/provider URL.


---

## Item 11a — `security.password_reset.request`

**Version:** `1.0.0`  

**Audience/role:** `parent_account_holder`, `student_account_holder`, `owner_rabbi_scheller`, `administrator_shloimie`  

**Allowed channel:** `email`  

**Protected link required:** Yes


### Trigger and committed state

**Trigger:** Send after a password-reset request and protected reset action are committed.

- password_reset_request.status = active
- account status permits reset
- protected reset action committed
- email policy decision = allowed
- reset-message intent committed


### Exact copy

**Subject:**

```text
Reset your One Time One Time password
```


**Title:** Not applicable.


**Body:**

```text
We received a request to reset the password for your ${account_role_label} account. Use the secure link below to choose a new password. For your security, the link may expire.

If you did not request this, ignore this email; your password has not been changed.
```


**CTA label:** `Reset password`  
**CTA target:** `${protected_password_reset_url}`  
**CTA fallback:** Do not send without a valid protected password-reset link.


### Variables and safe fallback

- `${account_role_label}` — optional; fallback: Use “account”.

- `${protected_password_reset_url}` — required; fallback: Do not send; invalidate or hold the unusable reset action according to security policy.


**Overall safe fallback:** Return the same neutral on-screen response whether or not an account exists. Do not expose account existence, a reset token or any credential.


### Consent, suppression and delivery policy

- Treat as account-security transactional email under the approved policy basis.
- Honor legal and security suppressions while avoiding account-enumeration disclosures.
- Do not reroute to WhatsApp or SMS without a separately approved recovery design.


**Idempotency:** At most one successful send per password_reset_request_reference, message_key and version.


**Audit event:** `communications.password_reset_request_sent`


### Prohibited claims or data

- A password, token, recovery code or secret in copy or logs.
- Account-existence disclosure on the public request screen.
- A raw provider URL.


---

## Item 11b — `security.password_reset.completed`

**Version:** `1.0.0`  

**Audience/role:** `parent_account_holder`, `student_account_holder`, `owner_rabbi_scheller`, `administrator_shloimie`  

**Allowed channel:** `email`  

**Protected link required:** No


### Trigger and committed state

**Trigger:** Send after the password change transaction commits.

- password_change.status = committed
- security-event timestamp persisted
- email policy decision = allowed
- completion-notice intent committed


### Exact copy

**Subject:**

```text
Your One Time One Time password was changed
```


**Title:** Not applicable.


**Body:**

```text
The password for your ${account_role_label} account was changed at ${changed_at_local}.

If you made this change, no action is needed. If you did not, use the official support path immediately.
```


**CTA label:** `Contact support`  
**CTA target:** `${security_help_url}`  
**CTA fallback:** Omit the CTA; retain the instruction to use the official support path.


### Variables and safe fallback

- `${account_role_label}` — optional; fallback: Use “account”.

- `${changed_at_local}` — optional; fallback: Replace “at ${changed_at_local}” with “recently”.

- `${security_help_url}` — optional; fallback: Omit the CTA.


**Overall safe fallback:** Send no credential or device detail. If the notification channel is unavailable, preserve the committed security event and surface it in the protected account/security view.


### Consent, suppression and delivery policy

- Treat as a security notification under the approved policy basis.
- Honor legal and security suppressions.
- Do not switch to WhatsApp or SMS without a separately approved security-notification policy.


**Idempotency:** At most one successful notice per password_change_event_reference, message_key and version.


**Audit event:** `communications.password_reset_completed_notice_sent`


### Prohibited claims or data

- The old or new password, token, IP address, device fingerprint or recovery secret.
- A link to an unapproved domain.
- Language implying Rabbi Scheller or Shloimie personally performed the change.


---

## Item 12 — `security.privileged_mfa_recovery.completed`

**Version:** `1.0.0`  

**Audience/role:** `owner_rabbi_scheller`, `administrator_shloimie`  

**Allowed channel:** `secure_operator_inbox`, `internal_email`  

**Protected link required:** Yes


### Trigger and committed state

**Trigger:** Send after a privileged MFA-recovery action is approved and committed.

- privileged_mfa_recovery.status = committed
- approval evidence persisted
- security-event timestamp persisted
- protected security-review link committed
- verified privileged notification route available
- notice intent committed


### Exact copy

**Subject:**

```text
Security notice: privileged MFA recovery completed
```


**Title:**

```text
Security notice: privileged MFA recovery completed
```


**Body:**

```text
A privileged MFA recovery action was completed for the ${privileged_role_label} account at ${recovery_completed_at_local}.

No recovery code or credential is included in this message. If you did not authorize this action, use the protected security page immediately.
```


**CTA label:** `Review account security`  
**CTA target:** `${protected_security_url}`  
**CTA fallback:** Do not send the notice through an unprotected route; escalate through the approved security process.


### Variables and safe fallback

- `${privileged_role_label}` — required; fallback: Do not send; the privileged role must be an allowlisted value.

- `${recovery_completed_at_local}` — required; fallback: Do not send; the security-event time is required.

- `${protected_security_url}` — required; fallback: Do not include a substitute raw admin/provider link.


**Overall safe fallback:** When the standard protected notification route is unavailable, follow the separately approved security-escalation procedure. Never downgrade to an unverified recipient or channel.


### Consent, suppression and delivery policy

- This is a privileged security notice controlled by access policy, not marketing consent.
- Send only to verified owner/administrator security routes.
- Do not use wording that impersonates Rabbi Scheller or Shloimie.


**Idempotency:** At most one successful notice per privileged_mfa_recovery_event_reference, message_key and version.


**Audit event:** `communications.privileged_mfa_recovery_notice_sent`


### Prohibited claims or data

- Recovery codes, MFA seeds, passwords, tokens, factor details or credentials.
- Unverified recipient details.
- Language claiming personal authorship by Rabbi Scheller or Shloimie.


---

## Item 13 — `login.member.holding_page`

**Version:** `1.0.0`  

**Audience/role:** `unauthenticated_member_login_visitor`  

**Allowed channel:** `public_web`  

**Protected link required:** No


### Trigger and committed state

**Trigger:** Render while member account activation/login is not available for the visitor.

- member_login_readiness = not_ready
- no login or activation-ready claim may be emitted
- page render independent of communications providers


### Exact copy

**Subject:** Not applicable.


**Title:**

```text
Member access is almost ready.
```


**Heading:** Same exact copy as the title.


**Body:**

```text
If you’ve already joined, we’ll email your login information as soon as your account is activated.
```


**CTA label:** `Return to One Time One Time`  
**CTA target:** `${transition_home_url}`  
**CTA fallback:** Omit the CTA; keep the required heading and body unchanged.


### Variables and safe fallback

- `${transition_home_url}` — optional; fallback: Render without a CTA.


**Overall safe fallback:** Render this static holding copy whenever activation is unavailable. Do not present a nonfunctional login form, fabricate an account state or promise a specific activation date.


### Consent, suppression and delivery policy

- The public page itself requires no messaging consent.
- The sentence does not authorize email; any later account email must pass its own policy checks.


**Idempotency:** Page renders are side-effect free; repeated views must not create accounts or message intents.


**Audit event:** `login.member_holding_page_viewed`


### Prohibited claims or data

- A claim that member access, credentials or activation are currently ready.
- A class link, account token, password or price.
- A specific activation deadline that has not been approved.


---

## Item 14a — `support.ticket.opened`

**Version:** `1.0.0`  

**Audience/role:** `support_requester`  

**Allowed channel:** `email`, `secure_in_app`  

**Protected link required:** Yes


### Trigger and committed state

**Trigger:** Send after the support ticket transaction commits.

- support_ticket.status = open
- ticket reference committed
- protected ticket-view link committed
- email policy decision = allowed
- opened-notice intent committed


### Exact copy

**Subject:**

```text
Support request ${ticket_reference} received
```


**Title:**

```text
Support request received
```


**Body:**

```text
We received your support request ${ticket_reference}. Our team will review it. Use the secure ticket page to see updates.
```


**CTA label:** `View support request`  
**CTA target:** `${protected_ticket_url}`  
**CTA fallback:** Do not send an email with a broken or unprotected ticket link; retain the in-app record.


### Variables and safe fallback

- `${ticket_reference}` — required; fallback: Do not send; a non-PII ticket reference is required.

- `${protected_ticket_url}` — required; fallback: Do not send the linked email notice; keep the ticket committed.


**Overall safe fallback:** Keep the ticket open and visible in the protected support system. Do not promise a response time or copy sensitive ticket content into an unprotected channel.


### Consent, suppression and delivery policy

- Treat as transactional support correspondence under the approved policy basis.
- Honor legal, complaint, hard-bounce and global safety suppressions.
- WhatsApp and SMS are not approved support-confirmation channels in this package.


**Idempotency:** At most one successful opened confirmation per support_ticket_reference, message_key and version.


**Audit event:** `communications.support_ticket_opened_sent`


### Prohibited claims or data

- A response-time or resolution-time promise.
- Sensitive ticket details in the subject/body.
- A raw attachment, provider or admin URL.


---

## Item 14b — `support.ticket.updated`

**Version:** `1.0.0`  

**Audience/role:** `support_requester`  

**Allowed channel:** `email`, `secure_in_app`  

**Protected link required:** Yes


### Trigger and committed state

**Trigger:** Send after a new support update transaction commits.

- support_ticket.status in open, pending, resolved
- support_update.status = committed
- protected ticket-view link committed
- email policy decision = allowed
- update-notice intent committed


### Exact copy

**Subject:**

```text
Support request ${ticket_reference} updated
```


**Title:**

```text
Support request updated
```


**Body:**

```text
There is an update on support request ${ticket_reference}. Use the secure ticket page to read the latest message.
```


**CTA label:** `View update`  
**CTA target:** `${protected_ticket_url}`  
**CTA fallback:** Do not send an email with a broken or unprotected ticket link; retain the in-app update.


### Variables and safe fallback

- `${ticket_reference}` — required; fallback: Do not send; a non-PII ticket reference is required.

- `${protected_ticket_url}` — required; fallback: Do not send the linked email notice; keep the update committed.


**Overall safe fallback:** Do not place the support update itself in external copy. Preserve the committed update in the protected ticket and record delivery status separately.


### Consent, suppression and delivery policy

- Treat as transactional support correspondence under the approved policy basis.
- Honor legal, complaint, hard-bounce and global safety suppressions.
- WhatsApp and SMS are not approved support-confirmation channels in this package.


**Idempotency:** At most one successful update notice per support_update_reference, message_key and version.


**Audit event:** `communications.support_ticket_updated_sent`


### Prohibited claims or data

- Sensitive support content, attachments or private notes in the subject/body.
- A response-time promise.
- A raw provider or admin URL.


---

## Item 14c — `support.ticket.resolved`

**Version:** `1.0.0`  

**Audience/role:** `support_requester`  

**Allowed channel:** `email`, `secure_in_app`  

**Protected link required:** Yes


### Trigger and committed state

**Trigger:** Send after the ticket resolution transaction commits.

- support_ticket.status = resolved
- resolution event committed
- protected ticket-view link committed
- email policy decision = allowed
- resolved-notice intent committed


### Exact copy

**Subject:**

```text
Support request ${ticket_reference} resolved
```


**Title:**

```text
Support request resolved
```


**Body:**

```text
Support request ${ticket_reference} has been marked resolved. Review the resolution on the secure ticket page. If the issue is not resolved for you, use the official support path to tell us.
```


**CTA label:** `Review resolution`  
**CTA target:** `${protected_ticket_url}`  
**CTA fallback:** Do not send an email with a broken or unprotected ticket link; retain the resolution in-app.


### Variables and safe fallback

- `${ticket_reference}` — required; fallback: Do not send; a non-PII ticket reference is required.

- `${protected_ticket_url}` — required; fallback: Do not send the linked email notice; keep the resolution committed.


**Overall safe fallback:** Keep the committed resolution visible in the protected support system. Do not claim the requester agreed with the resolution and do not invent a reopen feature.


### Consent, suppression and delivery policy

- Treat as transactional support correspondence under the approved policy basis.
- Honor legal, complaint, hard-bounce and global safety suppressions.
- WhatsApp and SMS are not approved support-confirmation channels in this package.


**Idempotency:** At most one successful resolved notice per support_resolution_event_reference, message_key and version.


**Audit event:** `communications.support_ticket_resolved_sent`


### Prohibited claims or data

- A claim that the requester confirmed resolution.
- A response-time promise or a reopen feature that is not available.
- Sensitive support content in the subject/body.


---

## Item 15 — `communications.secure_access_delayed`

**Version:** `1.0.0`  

**Audience/role:** `eligible_external_recipient`  

**Allowed channel:** `public_web`, `secure_in_app`, `email`, `whatsapp_consented`  

**Protected link required:** No


### Trigger and committed state

**Trigger:** Present or send only after an intended protected action is committed but its protected application link is unavailable or delayed.

- underlying business record remains committed
- recipient role and selected channel remain eligible
- protected application link status = unavailable_or_delayed
- no raw provider link is available to copy
- delay-status intent committed


### Exact copy

**Subject:**

```text
Secure access is delayed
```


**Title:**

```text
Secure access is delayed
```


**Body:**

```text
The secure link for this action is not available yet. No direct class or provider link is included. Use the official One Time One Time transition site to check the latest status.
```


**CTA label:** `Open One Time One Time`  
**CTA target:** `${transition_home_url}`  
**CTA fallback:** Omit the CTA and keep the delay statement; never substitute a raw class/provider URL.


### Variables and safe fallback

- `${transition_home_url}` — optional; fallback: Omit the CTA.


**Overall safe fallback:** Keep the underlying record committed and mark the outbound action delayed. Retry only under the approved retry policy. Never name the unavailable provider or expose its URL, identifier or error payload.


### Consent, suppression and delivery policy

- External email or WhatsApp delivery still requires independent channel eligibility and suppression checks.
- WhatsApp requires affirmative consent for the relevant purpose.
- Do not use this copy to contact a School lead about class, reminder, portal or Family access.
- Do not switch to SMS.


**Idempotency:** At most one external delay notice per recipient_reference, delayed_action_reference, delay_window, message_key and version; page/in-app renders are side-effect free.


**Audit event:** `communications.secure_access_delayed_presented`


### Prohibited claims or data

- Provider names, provider identifiers, raw error text or raw URLs.
- A promise that access will be restored by a specific time.
- A claim that the protected link is ready.


### SMS-length alternative — reference only

SMS is not an allowed channel in this package. This copy is retained only for future policy review.

```text
One Time One Time: secure access is delayed. Check the official transition site for status. No direct link is included.
```


### Notes

- The SMS-length alternative is reference copy only. SMS is not an allowed channel in this package.


---

## Item 16 — `communications.message_not_sent.operator_status`

**Version:** `1.0.0`  

**Audience/role:** `owner_rabbi_scheller`, `administrator_shloimie`, `authorized_operator`  

**Allowed channel:** `secure_operator_inbox`, `internal_email`  

**Protected link required:** Yes


### Trigger and committed state

**Trigger:** Create after a committed message intent is blocked by a consent, suppression, role or duplicate-send rule.

- message_intent.status = committed
- policy_evaluation.status = not_sendable
- allowlisted suppression reason persisted
- recipient represented by non-PII reference
- protected communication-status link committed


### Exact copy

**Subject:**

```text
Message not sent: policy rule applied
```


**Title:**

```text
Message not sent: policy rule applied
```


**Body:**

```text
No message was sent for ${message_key} to ${recipient_reference}.

Reason: ${suppression_reason_label}

The committed business record remains unchanged. Do not bypass this status by copying contact information into another channel.
```


**CTA label:** `Review communication status`  
**CTA target:** `${protected_communication_status_url}`  
**CTA fallback:** Keep the status in the secure operator inbox; do not send it through an unprotected route.


### Variables and safe fallback

- `${message_key}` — required; fallback: Do not render an ambiguous status.

- `${recipient_reference}` — required; fallback: Use a non-PII internal reference; never use an email address or phone number.

- `${suppression_reason_label}` — required; fallback: Use only an allowlisted policy reason; never expose raw provider errors.

- `${protected_communication_status_url}` — required; fallback: Retain the status in the secure operator inbox without an external alert.


**Overall safe fallback:** Do not send externally, do not alter the committed lead/account/ticket, and do not bypass the decision through another channel. A future retry requires a new policy evaluation and a valid idempotency claim.


### Consent, suppression and delivery policy

- This is an internal operational status governed by privileged access control.
- External recipient suppression is the subject of the status and must not be overridden.
- No contact detail may appear in the subject or body.


**Idempotency:** One operator status per message_intent_reference, policy_evaluation_reference, message_key and version.


**Audit event:** `communications.message_suppressed`


### Prohibited claims or data

- Recipient email address, phone number or full name.
- Raw provider errors, credentials, tokens or URLs.
- Instructions to bypass consent or suppression controls.
- Language implying personal authorship by Rabbi Scheller or Shloimie.


---
