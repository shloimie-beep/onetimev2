# Start Here

## Package identity

- **Package:** `OT-DAYONE-COMMUNICATIONS-COPY-PACK`
- **Version:** `1.0.0`
- **Prepared:** `2026-07-15`
- **Product:** One Time One Time with Rabbi Eli Scheller
- **Transition domain:** `join.onetimeonetime.com`
- **Scope:** copy, UX-state and communications-policy specification only

This package does not contain application code and does not activate anything. It does not call providers, send messages, create accounts, create Stripe objects, use real recipients or authorize live charges.

## Operating model

1. **Commit first.** A public Family signup commits the Family lead/contact before any email, WhatsApp, class, payment or other provider dependency is evaluated.
2. **Keep School separate.** A School signup commits a School lead for human follow-up only. It never creates or receives a class link, reminder, portal entitlement or Family message.
3. **Use channel-specific permission.** Immediate Family acknowledgement may use email and affirmative-consent WhatsApp. A phone number is not consent, and a failed channel does not authorize SMS or another channel.
4. **Use the fixed class schedule.** The daily live class starts at 7:00 p.m. Asia/Jerusalem. T-30 reminder intent is evaluated at 6:30 p.m. Asia/Jerusalem.
5. **Protect destinations.** Copy uses protected application-link variables. It never contains a raw Zoom, class, meeting or provider URL.
6. **Separate accounts.** Parent and student accounts are separate. Parents may reset or suspend student access but may never retrieve the current student password or secret.
7. **Use truthful identity.** Rabbi Eli Scheller is the owner and Shloimie is the administrator. System copy must not impersonate either person.
8. **Do not invent commerce facts.** No price is stated. Test or sandbox work does not authorize live Stripe charges.
9. **Do not overstate readiness.** Unavailable login, activation, protected-link or provider-dependent functionality is described as unavailable or delayed, never as ready.
10. **Retain the transition domain.** Production transition routing remains under `join.onetimeonetime.com`. Documentation examples use fictional `.example.test` hosts.

## Contents

| File | Purpose |
|---|---|
| `START-HERE.md` | Package scope, operating model and usage sequence |
| `MESSAGE-CATALOG.json` | Machine-readable catalog of 19 stable, versioned message records |
| `MESSAGE-COPY.md` | Human-readable exact copy and policy metadata for all 16 requested items |
| `VARIABLE-DICTIONARY.md` | Runtime variable syntax, validation, fallback and fictional examples |
| `ROLE-CHANNEL-MATRIX.md` | Role eligibility and permitted channel combinations |
| `CONSENT-SUPPRESSION-RULES.md` | Consent, suppression, fallback, retry, idempotency and audit rules |
| `LOGIN-READINESS-COPY.md` | Login holding, parent activation, student access and security copy |
| `SUPPORT-TICKET-COPY.md` | Opened, updated and resolved support-ticket confirmations |
| `DECISIONS-NEEDED.md` | Unresolved business, legal, security and operating decisions |
| `ACCEPTANCE-CHECKLIST.md` | Completed package checks and outstanding implementation gates |
| `SHA256SUMS.txt` | SHA-256 hashes for the ten content files |

## Coverage

The 16 requested items are covered by 19 stable message records:

- items 1–10 each map to one record;
- item 11 maps to password-reset request and completion records;
- items 12–13 each map to one record;
- item 14 maps to support-ticket opened, updated and resolved records;
- items 15–16 each map to one record.

`MESSAGE-CATALOG.json` contains the authoritative item-to-key mapping.

## Implementation sequence

1. Resolve every entry in `DECISIONS-NEEDED.md` that affects legal basis, security controls, routing or feature readiness.
2. Implement committed-state gates before any outbound provider call.
3. Implement role/channel eligibility from `ROLE-CHANNEL-MATRIX.md`.
4. Implement consent and suppression evaluation from `CONSENT-SUPPRESSION-RULES.md`.
5. Resolve variables only according to `VARIABLE-DICTIONARY.md`.
6. Render exact copy by stable `message_key` and `version`.
7. Atomically claim the message-specific idempotency key.
8. Dispatch only through an allowed, independently authorized channel.
9. Emit the specified audit event using non-PII references.
10. Test public success pages and committed records while every provider dependency is unavailable.

## Authority and precedence

When files appear to overlap, use this order:

1. Binding product facts in this file and `MESSAGE-CATALOG.json`
2. Exact copy in `MESSAGE-CATALOG.json`
3. Variable and protected-link rules in `VARIABLE-DICTIONARY.md`
4. Consent/suppression rules
5. Role/channel matrix
6. Human-readable companion documents

Any copy change requires a new message version and corresponding updates to all affected files and checksums.

## Non-production data

All illustrative URLs use `.example.test` and are nonfunctional. No real recipient, phone number, email address, class link, token, provider ID, password, secret, price or credential appears in this package.

The public product name and the required transition-domain policy are retained because they are binding product facts.

## Integrity verification

From the unzipped package directory:

```text
sha256sum -c SHA256SUMS.txt
```

Every listed file must report `OK`. The ZIP-level SHA-256 is provided with the downloadable artifact.
