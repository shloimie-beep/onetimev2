# Decisions Needed

Package version: `1.0.0`

No unresolved decision is represented by an operator placeholder in the copy. Until each decision below is approved, use the stated conservative behavior.

## D-01 — Family acknowledgement email basis

**Decision:** Confirm the approved legal/policy basis for the immediate Family email acknowledgement and define which email suppressions override it.

**Why it matters:** The message is transactional in purpose, but marketing opt-out, global do-not-contact, legal blocks, complaints and hard bounces may have different precedence.

**Conservative behavior:** Keep marketing permission and transactional-email eligibility separate. Honor legal, complaint, hard-bounce and global safety suppressions. Do not send when the basis is uncertain.

## D-02 — WhatsApp consent scope and evidence

**Decision:** Approve the exact consent language, capture surface, consent version, evidence fields, retention period and revocation path for WhatsApp.

**Why it matters:** The immediate acknowledgement and daily reminder are separate purposes unless policy explicitly permits one consent to cover both.

**Conservative behavior:** Require affirmative, current, purpose-specific WhatsApp consent. A supplied phone number, pre-checked box or consent to another channel is insufficient.

## D-03 — Reminder eligibility and schedule exceptions

**Decision:** Define who is reminder-eligible, whether reminders are on by default, how recipients pause reminders, and how holidays, cancellations, daylight-saving changes and special schedules are represented.

**Why it matters:** The baseline is 7:00 p.m. Asia/Jerusalem with T-30 evaluation at 6:30 p.m., but session-level exceptions need authoritative state.

**Conservative behavior:** Send only when a committed session explicitly remains active at 7:00 p.m. Asia/Jerusalem, the recipient is entitled, channel policy is allowed and the protected link exists.

## D-04 — Internal lead-alert routing

**Decision:** Decide whether both Rabbi Eli Scheller and Shloimie receive every new lead alert or whether Family/School alerts follow routing, duty or escalation rules.

**Why it matters:** The package recognizes Rabbi Scheller as owner and Shloimie as administrator but does not contain real contact routes.

**Conservative behavior:** Route only to verified privileged roles configured outside copy. Do not use personal contact details in templates or imply personal authorship.

## D-05 — School human-follow-up ownership and service expectations

**Decision:** Assign the human owner, approved follow-up channels, working hours, prioritization and any response-time commitment for School leads.

**Why it matters:** School signup promises human follow-up but intentionally does not promise a deadline.

**Conservative behavior:** Commit the School lead, show the public acknowledgement and create only the protected internal alert. Do not send automated Family, class, reminder or portal messages.

## D-06 — Parent and student activation sequence

**Decision:** Define whether the parent must activate before student access can become ready, how multiple parents/guardians are authorized, and what student display name is appropriate.

**Why it matters:** The student-ready notice requires an authorized parent relationship and must not disclose more student identity than necessary.

**Conservative behavior:** Require an active parent account and committed authorized relationship before sending the student-ready notice. Use `your student` when the display name is not explicitly approved.

## D-07 — Protected-link security profile

**Decision:** Set expiry, revocation, single-use, device/session binding, forwarding behavior and reissue rules for each protected-link class: class join, parent activation, student management, password reset, security review, lead review and support ticket.

**Why it matters:** The copy states only that certain links may expire. It does not claim single-use or other controls that have not been approved.

**Conservative behavior:** Use short-lived, server-authorized, allowlisted application links; exclude complete URLs from logs; do not send when a required protected link is absent.

## D-08 — Password-reset controls

**Decision:** Approve reset-link lifetime, rate limits, request throttling, session invalidation after change, treatment of suspended accounts and security escalation for unrecognized changes.

**Why it matters:** Copy must match the actual security behavior and remain neutral against account enumeration.

**Conservative behavior:** Use a neutral public response, issue no email until a reset action is committed, reveal no account-existence result and include no credential or device detail.

## D-09 — Privileged MFA-recovery governance

**Decision:** Define who may initiate and approve owner/administrator MFA recovery, whether dual approval is required, which sessions/factors are revoked and which verified routes receive the security notice.

**Why it matters:** Privileged recovery has higher security impact than ordinary password reset.

**Conservative behavior:** Do not complete or notify a recovery without persisted approval evidence, a committed event and a protected security-review route. Never send codes, seeds or factor details.

## D-10 — Support lifecycle and requester recourse

**Decision:** Define support statuses, who can resolve a ticket, whether and how a requester can reopen it, how long a ticket remains accessible and whether any service-level promise will be made.

**Why it matters:** The resolved copy deliberately does not claim requester agreement or promise a reopen feature.

**Conservative behavior:** Use received/updated/resolved notices without timing promises. Direct the requester to the protected ticket and official support path.

## D-11 — Support delivery basis and channel expansion

**Decision:** Confirm the transactional basis and suppression precedence for support email, and decide whether WhatsApp will ever be approved for support notifications.

**Why it matters:** Current package scope permits email and secure in-app only.

**Conservative behavior:** Do not send support confirmations by WhatsApp or SMS. Keep the protected ticket as the source of truth when email is blocked.

## D-12 — Provider-delay thresholds and cadence

**Decision:** Define when a temporary failure becomes user-visible, retry counts/backoff, the delay-window idempotency period, escalation ownership and whether an eventual recovery notice is needed.

**Why it matters:** Too many delay notices create noise; too few can leave users uninformed.

**Conservative behavior:** Preserve the committed record, retry the same intent under capped policy, issue at most one delay notice per approved window and never name a provider or expose a raw URL.

## D-13 — Sender identity, reply handling and signatures

**Decision:** Approve the display name, reply-to behavior, support routing and authentication configuration for each external and internal email class.

**Why it matters:** The product owner and administrator are real people, and system copy must not impersonate them.

**Conservative behavior:** Use the organizational signature `One Time One Time`. Do not use wording such as “I sent,” “I approved,” or “Rabbi Scheller asked me to” without a separately approved, audited template.

## D-14 — Localization, accessibility and formatting

**Decision:** Decide whether Day-One copy is English-only, which future languages are supported, how right-to-left layouts will be handled, and the accessibility requirements for email, WhatsApp and public pages.

**Why it matters:** Translation may alter line length, tone, time formatting and CTA labels.

**Conservative behavior:** Ship only the approved English copy, preserve semantic headings and accessible CTA labels, and do not machine-translate production messages without review.

## D-15 — Data and audit retention

**Decision:** Set retention periods and access controls for leads, consent evidence, suppression records, message intents, audit events, support tickets and security notices.

**Why it matters:** Idempotency, revocation evidence and incident review require records, but unnecessary personal data must not be retained.

**Conservative behavior:** Store non-PII references in routine communications audits, minimize message-body retention and never store complete protected links or credentials in logs.

## D-16 — Transition-domain route map

**Decision:** Approve the exact public paths under the fixed transition domain for home, login holding, support/security help and access status.

**Why it matters:** The host `join.onetimeonetime.com` is fixed, but route ownership and readiness are not specified.

**Conservative behavior:** Resolve `${transition_home_url}` only to an allowlisted transition route. Omit optional CTAs until the relevant route is live; do not invent a path.

## D-17 — SMS policy

**Decision:** Decide whether SMS will remain disabled or enter a separate consent, legal, vendor and copy-approval workstream.

**Why it matters:** Two SMS-length alternatives are supplied for future review, but no SMS channel is authorized.

**Conservative behavior:** Do not create or send SMS. Do not treat WhatsApp consent as SMS consent.

## D-18 — Billing and Stripe go-live authority

**Decision:** Separately approve any future price, billing plan, tax language, refund terms, live Stripe configuration and authority to create charges.

**Why it matters:** This package contains no price and no billing message. Sandbox/test activity does not authorize live charges.

**Conservative behavior:** Do not insert a price, payment confirmation or charge CTA into any message. Do not create a live Stripe object or charge from this package.

## D-19 — Final brand, legal and security sign-off

**Decision:** Name the accountable approvers for brand voice, lifecycle policy, privacy/legal basis, account security and production readiness.

**Why it matters:** Copy approval alone does not establish operational authorization.

**Conservative behavior:** Treat this package as a Day-One specification, not permission to activate providers, recipients, accounts or payments.
