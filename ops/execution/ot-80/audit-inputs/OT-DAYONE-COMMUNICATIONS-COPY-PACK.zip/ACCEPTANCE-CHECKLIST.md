# Acceptance Checklist

Package version: `1.0.0`

## Package completeness — verified

- [x] `START-HERE.md` is present.
- [x] `MESSAGE-CATALOG.json` is present and parses as UTF-8 JSON.
- [x] `MESSAGE-COPY.md` is present.
- [x] `VARIABLE-DICTIONARY.md` is present.
- [x] `ROLE-CHANNEL-MATRIX.md` is present.
- [x] `CONSENT-SUPPRESSION-RULES.md` is present.
- [x] `LOGIN-READINESS-COPY.md` is present.
- [x] `SUPPORT-TICKET-COPY.md` is present.
- [x] `DECISIONS-NEEDED.md` is present.
- [x] `ACCEPTANCE-CHECKLIST.md` is present.
- [x] `SHA256SUMS.txt` is generated after the ten content files.
- [x] The ZIP contains the eleven required filenames and no extra payload files.

## Catalog structure — verified

- [x] The catalog contains 19 message records covering all 16 requested items.
- [x] Every message has a stable `message_key` and semantic version.
- [x] Message keys are unique.
- [x] Every message identifies audience/role, trigger, required committed state and allowed channel.
- [x] Every message provides exact subject/title/body/CTA fields, using `null` where a field is not applicable.
- [x] Every message documents variables, safe fallback, protected-link requirement, consent/suppression, idempotency, audit event and prohibited claims/data.
- [x] SMS-length alternatives appear only where useful and are labeled reference-only; SMS is not an allowed channel.
- [x] Runtime variables use `${variable_name}` syntax.
- [x] No literal double-brace operator placeholders appear.
- [x] Every runtime variable used by the catalog is documented in `VARIABLE-DICTIONARY.md`.
- [x] No undocumented runtime variable appears in companion copy.

## Binding product facts — verified

- [x] Public Family signup commits lead/contact first and is provider-independent.
- [x] School signup creates a human-follow-up-only School lead.
- [x] School leads are prohibited from class links, reminders, portal entitlements and Family messages.
- [x] Immediate Family acknowledgement is provided for email and affirmative-consent WhatsApp.
- [x] Daily class start is stated as 7:00 p.m. Asia/Jerusalem.
- [x] T-30 reminder evaluation is stated as 6:30 p.m. Asia/Jerusalem.
- [x] Reminder copy requires a protected application link.
- [x] Raw class, meeting, Zoom and provider URLs are prohibited.
- [x] Parent and student accounts are separate.
- [x] Parent copy permits reset/suspend but never retrieval of the student’s current password or secret.
- [x] Rabbi Eli Scheller is identified as owner and Shloimie as administrator.
- [x] Copy does not impersonate Rabbi Scheller or Shloimie.
- [x] No price is invented.
- [x] Sandbox/test work is explicitly not live-charge authorization.
- [x] `join.onetimeonetime.com` remains the transition domain.
- [x] Unavailable login and protected-link states are not described as ready.

## Exact-copy requirements — verified

- [x] Family signup success-page copy is present.
- [x] Immediate Family email acknowledgement is present.
- [x] Immediate Family WhatsApp acknowledgement is present.
- [x] T-30 class reminder email is present.
- [x] T-30 class reminder WhatsApp is present.
- [x] School public acknowledgement contains human-follow-up-only language.
- [x] Protected Family owner alert is present.
- [x] Protected School owner alert is present.
- [x] Parent invitation/activation copy is present.
- [x] Student access-ready notice to the parent is present.
- [x] Password-reset request and completion notices are present.
- [x] Privileged MFA-recovery/security notice is present.
- [x] Member Login heading is exactly `Member access is almost ready.`
- [x] Member Login body is exactly `If you’ve already joined, we’ll email your login information as soon as your account is activated.`
- [x] Support opened, updated and resolved confirmations are present.
- [x] Provider unavailable/delayed copy omits provider names and raw links.
- [x] Consent/suppression-safe operator no-send status is present.

## Privacy and safety — verified

- [x] No real recipient email address or phone number appears.
- [x] No real class link, token, provider ID, password, secret, recovery code, price or credential appears.
- [x] Illustrative URLs use `.example.test`.
- [x] The only non-example host named is the binding transition-domain policy, `join.onetimeonetime.com`.
- [x] Protected links are represented by documented variables in exact message copy.
- [x] Operator alerts use non-PII references and protected destinations.
- [x] School and Family role boundaries are repeated in catalog, matrix and suppression policy.
- [x] Channel fallback requires independent authorization; SMS fallback is prohibited.
- [x] Audit guidance prohibits contact details, complete protected URLs and credentials.

## Integrity — verified

- [x] JSON was parsed after writing.
- [x] Stable keys and audit-event names were checked for uniqueness.
- [x] Variable usage was compared with the dictionary.
- [x] Required exact Member Login copy was compared character-for-character.
- [x] `SHA256SUMS.txt` was generated from the final ten content files.
- [x] Every checksum in `SHA256SUMS.txt` was revalidated.
- [x] The ZIP was reopened and its file list was compared with the required list.
- [x] The ZIP-level SHA-256 was calculated after packaging.

## Production/go-live gates — intentionally not completed by this copy package

- [ ] Resolve and approve every applicable item in `DECISIONS-NEEDED.md`.
- [ ] Approve legal/policy basis and suppression precedence for each external message purpose.
- [ ] Approve WhatsApp consent language, evidence and revocation behavior.
- [ ] Implement committed-state and role-eligibility gates.
- [ ] Implement protected-link authorization, expiry and revocation controls.
- [ ] Implement atomic idempotency and provider-independent outbox behavior.
- [ ] Implement audit events without PII, complete protected URLs or credentials.
- [ ] Configure verified internal routes for Rabbi Scheller and Shloimie.
- [ ] Validate parent/student authorization and credential-separation behavior.
- [ ] Security-review password reset and privileged MFA recovery.
- [ ] Test provider-unavailable behavior without exposing provider names or raw links.
- [ ] Test that School leads cannot receive Family/class/account messages under any fallback path.
- [ ] Validate accessibility and any approved localization.
- [ ] Approve transition-domain route ownership and readiness.
- [ ] Separately authorize any future live Stripe object, price or charge.
- [ ] Activate no provider, recipient, account or payment solely from this package.
