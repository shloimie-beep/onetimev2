# Login Readiness Copy

Package version: `1.0.0`

This file collects account-readiness and security copy. `MESSAGE-CATALOG.json` remains authoritative.

## Readiness state model

| State | Permitted user-facing behavior |
|---|---|
| Login/activation unavailable | Render the exact Member Login holding page. Do not show a nonfunctional login form and do not claim an account is ready. |
| Parent activation ready | Send `account.parent.invitation` only after the parent account and protected activation action are committed. |
| Parent active; authorized student access ready | Send `account.student_access_ready.parent_notice` only after the student state and parent relationship are committed. |
| Password reset requested | Return a neutral public response; send `security.password_reset.request` only after a protected reset action is committed. |
| Password changed | Commit the security event first, then send `security.password_reset.completed`. |
| Privileged MFA recovery completed | Commit approval and recovery evidence first, then send the protected privileged notice. |

## Member Login holding page

**Message key:** `login.member.holding_page`  
**Version:** `1.0.0`  
**Allowed channel:** public web  
**Protected link required:** no

**Title**

```text
Member access is almost ready.
```

**Heading**

```text
Member access is almost ready.
```

**Body**

```text
If you’ve already joined, we’ll email your login information as soon as your account is activated.
```

**CTA**

```text
Return to One Time One Time
```

Target: `${transition_home_url}`

The heading and body above are binding and must remain exact:

- Heading: `Member access is almost ready.`
- Body: `If you’ve already joined, we’ll email your login information as soon as your account is activated.`

The CTA is optional. If `${transition_home_url}` is unavailable, render the exact heading and body without a CTA.

### Holding-page prohibitions

- Do not show a password field, “forgot password” path or activation button that does not function.
- Do not imply that an account exists for every visitor.
- Do not promise a specific activation date.
- Do not create a message intent merely because the page was viewed.
- Do not present a class link, raw provider link, token, price or payment action.

## Parent invitation and activation

**Message key:** `account.parent.invitation`  
**Version:** `1.0.0`  
**Allowed channel:** email  
**Protected link required:** yes

**Subject**

```text
Activate your One Time One Time parent account
```

**Body**

```text
Hi ${parent_first_name},

Your parent account is ready to activate. Use the secure link below to choose your password. This link is for you and may expire.

Parent and student accounts are separate. A parent can reset or suspend student access, but cannot view the student’s current password.

— One Time One Time
```

**CTA**

```text
Activate parent account
```

Target: `${protected_parent_activation_url}`

### Required gates

- Parent account status is `activation_ready`.
- The parent identity/contact relationship is verified.
- The protected activation action is committed.
- Email policy evaluation is allowed.
- The invitation idempotency claim succeeds.

If any gate fails, do not send. If activation is not ready, use the public holding page; do not weaken the invitation copy.

## Student access-ready notice to the parent

**Message key:** `account.student_access_ready.parent_notice`  
**Version:** `1.0.0`  
**Allowed channel:** email  
**Protected link required:** yes

**Subject**

```text
Student access is ready
```

**Body**

```text
Hi ${parent_first_name},

Student access is ready for ${student_display_name}. Parent and student accounts are separate.

For security, the student’s current password cannot be viewed. From your parent account, you can reset or suspend the student’s access when needed.

— One Time One Time
```

**CTA**

```text
Manage student access
```

Target: `${protected_student_management_url}`

### Account separation rule

The parent account and student account are separate principals. Parent controls may permit reset or suspension. They must not reveal, retrieve or reconstruct the student’s current password or secret. No copy may suggest shared credentials.

## Password-reset request

**Message key:** `security.password_reset.request`  
**Version:** `1.0.0`  
**Allowed channel:** email  
**Protected link required:** yes

**Subject**

```text
Reset your One Time One Time password
```

**Body**

```text
We received a request to reset the password for your ${account_role_label} account. Use the secure link below to choose a new password. For your security, the link may expire.

If you did not request this, ignore this email; your password has not been changed.
```

**CTA**

```text
Reset password
```

Target: `${protected_password_reset_url}`

### Public request-screen behavior

The public screen must use the same neutral response whether an account exists or not. The reset email is created only after an eligible account and protected reset action are committed. Do not expose account existence, a token or a reason that an account did not qualify.

## Password-change completion notice

**Message key:** `security.password_reset.completed`  
**Version:** `1.0.0`  
**Allowed channel:** email  
**Protected link required:** no; the optional support CTA must use an allowlisted official URL

**Subject**

```text
Your One Time One Time password was changed
```

**Body**

```text
The password for your ${account_role_label} account was changed at ${changed_at_local}.

If you made this change, no action is needed. If you did not, use the official support path immediately.
```

**CTA**

```text
Contact support
```

Target: `${security_help_url}`

The notice must not include an old/new password, token, device fingerprint, IP address or recovery secret.

## Privileged MFA-recovery notice

**Message key:** `security.privileged_mfa_recovery.completed`  
**Version:** `1.0.0`  
**Allowed channels:** secure operator inbox and verified internal email  
**Protected link required:** yes

**Subject**

```text
Security notice: privileged MFA recovery completed
```

**Title**

```text
Security notice: privileged MFA recovery completed
```

**Body**

```text
A privileged MFA recovery action was completed for the ${privileged_role_label} account at ${recovery_completed_at_local}.

No recovery code or credential is included in this message. If you did not authorize this action, use the protected security page immediately.
```

**CTA**

```text
Review account security
```

Target: `${protected_security_url}`

Rabbi Eli Scheller is the owner and Shloimie is the administrator. Route notices by verified role. Do not word the notice as though either person personally authored, approved or performed the recovery unless a separately audited action and separately approved template support that statement.

## Protected-link failure

When a required activation, reset, student-management or security link cannot be created:

1. keep the underlying account/security record committed;
2. do not send a broken or unprotected link;
3. do not claim the feature is ready;
4. record a readiness delay;
5. use `communications.secure_access_delayed` only on an independently eligible channel;
6. never substitute a raw admin, provider, class or meeting URL.

## Billing boundary

No account-readiness message contains a price or payment claim. Test or sandbox Stripe work does not authorize a live charge, and this package creates no Stripe object.
