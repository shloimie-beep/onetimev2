# OPS-07 — Corrective pull-request contract

Create a draft pull request from `codex/ops-07-security-privacy-corrective-58746abd` to the dynamically selected integration branch only after all source edits are committed and all available local gates complete.

Suggested title:

`[OPS-07] Security and learner-privacy corrective review`

Required body sections:

1. Packet ID and exact base/corrective SHAs.
2. Candidate-resolution classification and included lane ancestry.
3. Threat-model scope and explicit exclusions.
4. Prior findings reproduced/not reproduced, including OT-24, OT-26, OT-34, and OT-38 behavior.
5. New findings with severity, owner, and disposition.
6. Root causes and scoped fixes.
7. Authorization, PostgreSQL concurrency/isolation, browser role, provider fixture, ingestion, prompt-safety, privacy lifecycle, header, dependency, secret, and data-scan evidence.
8. Migrations, rollback/readback, and compatibility impact.
9. Blocked environmental checks. Missing credentials or provider resources remain blockers, not successes.
10. External mutation counters, all zero.
11. Residual risks and human decisions required.

Do not label the pull request release-ready while any S0/S1 finding, gate failure, candidate ambiguity, or required environmental proof remains unresolved.
