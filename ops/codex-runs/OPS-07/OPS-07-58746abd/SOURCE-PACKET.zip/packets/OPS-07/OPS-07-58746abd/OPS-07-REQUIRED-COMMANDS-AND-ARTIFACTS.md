# OPS-07 — Required commands and evidence artifacts

Commands may be adapted to the repository's package manager and scripts only after recording the reason in `DECISIONS.md`. All outputs must be captured without secrets and linked to evidence records.

## Baseline and packet integrity

```bash
sha256sum -c OPS-07-CHECKSUMS.sha256
git status --short
git rev-parse HEAD
git show --no-patch --format=fuller HEAD
git diff --check
```

## Source and history audit

```bash
git grep -n -E 'account_key|product_key|household_key|learner_key|guardian_user_ref|assigned_user_key'
git grep -n -E 'Cache-Control|setCookie|sameSite|secure:|httpOnly|csrf|return_to|safeReturn'
git grep -n -E 'webhook|signature|timestamp|nonce|replay|idempot|update_id|event_id|delivery_id'
git grep -n -E 'console\.|logger\.|analytics|support.*export|request\.body|req\.body'
git grep -n -E 'https?://|passcode|join_url|playback|token|secret|recovery_code'
```

The grep results are triage only. Each match requires semantic review; do not delete legitimate security code merely to make a scan empty.

## Disposable PostgreSQL

Use an isolated PostgreSQL container or CI service with a unique database name. Refuse any URL whose host/name matches production inventory.

Required database evidence:

- Fresh migration from empty database.
- Upgrade migration from the selected candidate's prior migration boundary.
- Migration checksum/readback and second-run idempotency behavior.
- Query plans for tenant/household/learner/assignee/inbox/outbox hot paths.
- At least two independent pools/processes for rate limit, learner binding, recovery code, idempotency, optimistic concurrency, webhook dedupe, suppression, and deletion/export races.
- Transaction isolation level recorded for every race; use row/advisory locks and unique constraints intentionally.
- Database dump/schema output sanitized and hashed.

## Browser role suite

Run isolated Playwright contexts for anonymous, viewer, owner, admin, parent primary guardian, parent guardian, support-only guardian, student, disabled member, revoked guardian, cross-account user, and cross-product user. Capture:

- Requests and redirects, with bodies and cookies excluded from evidence.
- Response status and security/cache headers.
- Cookies and browser storage field names/flags, never values.
- Route accessibility, direct navigation, bfcache/logout behavior, role UI exclusions, and error-state privacy.
- Synthetic-only screenshots scanned for prohibited patterns.

## Provider fixture suite

Use local raw-byte fixtures and injected synthetic secrets. Stub DNS/network so any attempt to reach a real provider fails the test. Test Stripe TEST, Telegram, WhatsApp, Vimeo/content, Zoom, support bridge, and social publishing. Record missing protected credentials as `BLOCKED_ENVIRONMENTAL` only for optional read-only canaries; local authenticity/replay tests remain mandatory.

## Scans

Run the repository's existing formatter, typecheck, lint, unit, integration, build, browser, secret, brand, dependency, and database checks. Add:

- Lockfile/SBOM vulnerability scan with reachability assessment.
- Git-history and built-artifact secret scan.
- Prohibited-data scanner over logs, metrics, traces, analytics fixtures, database evidence, screenshots, test reports, support exports, and browser storage/network records.
- CSP/security-header snapshot on public and every private route/error.
- Static route-to-service-to-query scope inventory.

## Required run artifacts

Store under `ops/codex-runs/OPS-07/OPS-07-58746abd/`:

- `ORIGINAL-PROMPT.md`
- `STATE.json`
- `BASE-RESOLUTION.json`
- `CHECKPOINT.md`
- `DECISIONS.md`
- `READONLY-AUDIT.md`
- `PRIOR-FINDINGS.json`
- `NEW-FINDINGS.json`
- `AUTHORIZATION-RESULTS.json`
- `NEGATIVE-TEST-RESULTS.json`
- `POSTGRESQL-RESULTS.json`
- `BROWSER-RESULTS.json`
- `PROVIDER-FIXTURE-RESULTS.json`
- `INGESTION-RESULTS.json`
- `PROMPT-SAFETY-RESULTS.json`
- `PRIVACY-LIFECYCLE-RESULTS.json`
- `DATA-SCAN-RESULTS.json`
- `DEPENDENCY-RESULTS.json`
- `SECURITY-HEADERS.json`
- `EXTERNAL-MUTATIONS.json`
- `TEST-RESULTS.md`
- `SEVERITY-OWNER-DISPOSITION.json`
- `FINAL-REPORT.md`
- `CHECKSUMS.sha256`

Every JSON artifact must parse, validate against its declared schema where one is supplied, and contain actual values. No unresolved template markers are allowed.
