# OPS-07 — Authorization matrix

Every allowed decision requires an explicit route check, service check, and SQL predicate or a documented invariant proven by schema constraints. Configuration constants are not a substitute for the authenticated principal when more than one account, product, or membership can exist.

| ID | Principal | Action/resource | Enforcement points | Required scope predicates | Expected decision |
|---|---|---|---|---|---|
| `OPS-07-AUTHZ-001` | Anonymous | Public landing GET | public route | none | Allow public D0 only; no session/private cache |
| `OPS-07-AUTHZ-002` | Anonymous | Submit Family signup | lead route | account/product from approved deployment context; public contract | Allow bounded create; no existing identity disclosure |
| `OPS-07-AUTHZ-003` | Anonymous | Submit School signup | lead route | same as AUTHZ-002 | Allow lead-only acknowledgement; never class/member access |
| `OPS-07-AUTHZ-004` | Anonymous | CRM/portal/content/billing API | session resolver | none | Deny 401, private no-store, no object-existence signal |
| `OPS-07-AUTHZ-005` | Viewer member | CRM list/detail | route + service + SQL | active membership; account/product; viewer capability | Allow read only if product policy permits; deny all writes |
| `OPS-07-AUTHZ-006` | Viewer member | Owner dashboard/classes/content administration | capability service | active account/product membership and role | Deny 403 with no sensitive data |
| `OPS-07-AUTHZ-007` | Owner | CRM list/detail/search | route + service + SQL | active owner membership; account/product; query context | Allow; signed cursor and private POST search |
| `OPS-07-AUTHZ-008` | Admin | CRM list/detail/search | route + service + SQL | active admin membership; account/product | Allow within granted product only |
| `OPS-07-AUTHZ-009` | Owner/Admin | Create/update/assign contact | route + service + SQL | recent session, CSRF, active membership, assignee same scope/status, version/idempotency | Allow and audit changed field names only |
| `OPS-07-AUTHZ-010` | Owner/Admin | MFA factor replace/revoke | auth service + SQL | active privileged membership; recent MFA/password step-up; session family | Allow after step-up; revoke/rotate affected sessions |
| `OPS-07-AUTHZ-011` | Disabled former owner/admin | Any private route | session resolver + membership query | status active and security/session version match | Deny; existing sessions invalidated |
| `OPS-07-AUTHZ-012` | Owner from account A | Account B CRM ID | service + SQL | actor account/product predicates | Deny privacy-safe 404/403; identical shape/timing |
| `OPS-07-AUTHZ-013` | Admin from product A | Product B CRM ID | service + SQL | actor product predicate | Deny with no cross-product row access |
| `OPS-07-AUTHZ-014` | Parent primary guardian | Own household dashboard | portal actor + service + SQL | active guardian relationship; authority not support_only; account/product/household | Allow |
| `OPS-07-AUTHZ-015` | Parent guardian | Own household learner read/update | portal actor + service + SQL | active guardian; required capability; learner in household | Allow policy-permitted operation |
| `OPS-07-AUTHZ-016` | Support-only guardian | Household private dashboard or learner mutation | service capability | authority support_only excluded | Deny without revealing learner count |
| `OPS-07-AUTHZ-017` | Revoked guardian | Former household | actor resolver + SQL | relationship status active | Deny and invalidate cached subject |
| `OPS-07-AUTHZ-018` | Parent household A | Guessed household B | service + SQL | authorized_households contains exact key; SQL account/product/household | Deny privacy-safe not found |
| `OPS-07-AUTHZ-019` | Parent household A | Guessed learner in household B | service + SQL | learner predicate includes authorized household | Deny; no sibling/household inference |
| `OPS-07-AUTHZ-020` | Parent | Student setup/reset/suspend/restore/revoke sessions | portal service + lifecycle adapter | own household learner; capability; CSRF; idempotency; version where applicable | Allow operation only; never return secret/current credential/session token |
| `OPS-07-AUTHZ-021` | Parent | Student impersonation/view-as/token exchange | all layers | no capability exists | Deny; endpoint absent or 403 |
| `OPS-07-AUTHZ-022` | Student | Own dashboard | student subject resolver + service + SQL | active session; exactly one active learner link; active learner/access state | Allow own learner only |
| `OPS-07-AUTHZ-023` | Student | Sibling dashboard/materials/progress | student service + SQL | server-derived learner only; ignore submitted learner IDs | Deny/no route; no sibling identifier in response |
| `OPS-07-AUTHZ-024` | Student | Parent controls/billing/CRM/admin | capability service | student capability set | Deny; controls absent in browser |
| `OPS-07-AUTHZ-025` | Student | Own protected class launch | service + entitlement + target vault | own learner, active entitlement, class state, one-time action | Allow opaque internal action only |
| `OPS-07-AUTHZ-026` | Student | KB helper query | helper policy + retrieval | own learner scope; authorized Rabbi corpus; safe tool policy | Allow scoped grounded answer only |
| `OPS-07-AUTHZ-027` | Owner/Admin | Household/learner data | explicit admin capability | real membership plus documented capability | Deny by default unless product contract explicitly grants |
| `OPS-07-AUTHZ-028` | Stripe TEST sender | Billing webhook | raw ingress + verifier + inbox | valid TEST signature/timestamp/event ID/account/mode | Accept once; project allowed transition only |
| `OPS-07-AUTHZ-029` | Forged Stripe sender | Billing webhook | raw ingress | invalid/missing signature or live mode | Deny before write |
| `OPS-07-AUTHZ-030` | Telegram provider | Webhook update | ingress + identity | valid configured secret channel, fresh receipt policy, unique update ID, allowlisted bot | Accept once; bind chat/actor |
| `OPS-07-AUTHZ-031` | Unknown Telegram chat | Private command | identity/capability | approved chat mapping and active membership | Deny generic; no account existence disclosure |
| `OPS-07-AUTHZ-032` | WhatsApp provider | Webhook message | raw ingress + verifier | valid raw-body signature, unique provider message ID | Accept once into encrypted/minimized inbox |
| `OPS-07-AUTHZ-033` | Unlinked WhatsApp user | Private account query | assistant policy | verified short-lived household-approved grant | Deny; public facts only |
| `OPS-07-AUTHZ-034` | Content publisher | Publication manifest | signed internal ingress | valid key/version/timestamp/nonce/delivery ID/checksums/sequence | Accept once if content privacy flags pass |
| `OPS-07-AUTHZ-035` | Unapproved content publisher | Publication manifest | signed internal ingress | no valid publisher identity | Deny before projection |
| `OPS-07-AUTHZ-036` | Vimeo/Zoom callback | Provider event | provider adapter + inbox | provider-supported authentication, freshness, dedupe, expected account/resource | Accept once; no raw URL exposure |
| `OPS-07-AUTHZ-037` | Support bridge | Create/confirm support action | signed bridge + service | valid bridge identity, nonce, bounded timestamp, actor scope, explicit confirmation | Allow minimized action only |
| `OPS-07-AUTHZ-038` | AI/helper model | Tool invocation | policy gateway | pre-authorized tool, exact schema, actor capability, data scope | Allow least-privilege operation or deny |
| `OPS-07-AUTHZ-039` | Uploaded content | KB indexing | ingestion + approval | validated type/size/source; human-approved Rabbi content; no learner-private flags | Allow after quarantine/approval |
| `OPS-07-AUTHZ-040` | Learner private question | Global KB/social/log/export | policy + data sinks | learner scope and private classification | Deny propagation; retain only approved minimized record if necessary |
| `OPS-07-AUTHZ-041` | Privacy requester | Own export | privacy service | verified identity, account/household/learner authority, recent auth | Allow scoped export with audit |
| `OPS-07-AUTHZ-042` | Privacy requester | Other household export/deletion | privacy service + SQL | exact authority and subject scope | Deny without existence signal |
| `OPS-07-AUTHZ-043` | Suppressed contact | Any outbound delivery | claim + dispatch policy | current suppression must be active/eligible | Deny/skip at both checkpoints |
| `OPS-07-AUTHZ-044` | Deleted/tombstoned subject | Search/retrieval/export/send | all services | deletion state and legal retention policy | Deny ordinary use; expose only authorized audit/tombstone metadata |
| `OPS-07-AUTHZ-045` | Operator/support export consumer | Logs/support export | export policy | explicit role, purpose, field allowlist | Allow redacted D1 only; no D2-D5 by default |


## Matrix proof rules

- Execute each deny case through the mounted HTTP route, the service API, and a direct repository call where the repository is exported or test-accessible.
- Prove zero side effects with row counts, audit-event expectations, outbox counts, and unchanged versions.
- Cross-scope denies must use indistinguishable status/body shapes and bounded timing distributions.
- A role string stored on a user row is insufficient. Validate a real active account/product membership and any guardian/learner relationship required by the action.
- Owner/admin privileged operations require MFA assurance and recent step-up; a stale MFA-authenticated session is not recent proof.
- Student actor resolution must return exactly one active learner or fail closed. The HTTP request may never select the learner subject.
