# OPS-07 — Threat model and data flows

## Security objectives

1. Enforce account, product, real membership, role, household, guardian relationship, and learner scope at route, service, and SQL layers.
2. Treat learner identity, questions, progress, support text, contact data, and access state as private data with strict minimization.
3. Prevent credential, provider target, passcode, token, secret, contact, child free-text, and private-question leakage.
4. Authenticate every inbound provider event, enforce freshness and replay resistance, and make mutations idempotent.
5. Keep AI/helper inputs untrusted and tools capability-limited; retrieval authorization occurs before search.
6. Preserve auditability without storing sensitive payloads.

## Principals and adversaries

- Anonymous visitor; abusive signup client; credential stuffer.
- Authenticated viewer, owner, admin, parent, support-only guardian, and student.
- Parent from another household; sibling student; user from another account or product.
- Stolen session or CSRF token holder; former/disabled member; revoked guardian.
- Forged, stale, replayed, reordered, duplicated, or malformed provider webhook sender.
- Malicious uploaded file, archive, remote URL, content publisher, or retrieved document.
- Prompt-injection author acting through Telegram, WhatsApp, student KB, support triage, or authorized content.
- Curious operator, log/analytics consumer, support exporter, or dependency compromise.

## Data classes

| Class | Examples | Required handling |
|---|---|---|
| D0 Public | Landing copy, published Rabbi content explicitly approved for public use | Integrity controls; no private joins. |
| D1 Operational | Opaque IDs, state enums, timestamps, redacted audit reasons | Least privilege; bounded retention. |
| D2 Contact private | Email, phone, location, family/school identity, CRM notes | Encryption where appropriate, no URL/log leakage, account/product scope. |
| D3 Learner private | Learner profile, household links, progress, questions, support text | Strict learner/guardian authorization, minimization, no sibling inference. |
| D4 Authentication secret | Password hash, session token, CSRF secret, MFA seed, recovery code | Hash/encrypt, one-time display where required, never log/export. |
| D5 Provider secret/target | API keys, signatures, webhook secrets, join URLs, passcodes, playback links | Server-only vault/reference, ephemeral resolution, never raw in DTOs/logs. |
| D6 Regulated lifecycle | Consent version, suppression, deletion/export state, retention deadline | Immutable provenance, current-policy enforcement, auditable transitions. |

## Trust boundaries

- Browser ↔ public web app.
- Browser ↔ authenticated owner/admin/parent/student APIs.
- Web/worker processes ↔ PostgreSQL.
- Webhook ingress ↔ provider adapters.
- Content/attachment ingress ↔ validation/sandbox/storage.
- Retrieval service ↔ authorized Rabbi corpus.
- AI helper ↔ deterministic policy layer and allowlisted tools.
- Application ↔ logs, metrics, analytics, support export, and evidence output.
- Local test environment ↔ disposable PostgreSQL and mocked providers.

## Data-flow register

| Flow | Source → sink | Sensitive fields | Mandatory controls |
|---|---|---|---|
| `OPS-07-DF-01` | Public signup → lead normalization → contact/lead transaction → sink outbox | contact data, consent, classification | Rate limit, canonical identity, request-hash idempotency, duplicate conflict policy, no partial write, suppression default. |
| `OPS-07-DF-02` | Login → password verification → MFA challenge/recovery → session | password, factor seed, recovery code, session/CSRF | Constant work, durable limits, short pre-auth, anti-replay, recent assurance, rotation/revocation, secure cookies, no-store. |
| `OPS-07-DF-03` | Owner/admin browser → CRM route → service → SQL | contact data, notes, assignee | Real membership, capability, principal-bound tenant scope, POST private search, signed cursor, optimistic concurrency, audit. |
| `OPS-07-DF-04` | Parent browser → guardian relationship → household/learner service → SQL | household, learner, access state | Active guardian relationship, household predicate in SQL, privacy-safe not-found, idempotency/version, no impersonation. |
| `OPS-07-DF-05` | Student session → identity link → exactly one learner → dashboard/helper/content | learner data, question, progress | Unique active mapping, fail closed on multiplicity, server-derived subject, no sibling identifiers or timing inference. |
| `OPS-07-DF-06` | Parent/student protected class action → launch service → provider target vault | class entitlement, provider URL/passcode | Reauthorize at launch, opaque one-time reference, no raw target in client/storage/logs, expiry and replay controls. |
| `OPS-07-DF-07` | Approved content publisher → signed manifest → projection → KB index → authorized retrieval | Rabbi content, learner query | Raw-byte authentication, sequence/idempotency, approval state, learner-private flags, authorization before retrieval, source-bound answers. |
| `OPS-07-DF-08` | Stripe TEST webhook → billing inbox → entitlement projection | provider IDs, household entitlement | TEST-mode enforcement, official raw-body verification, timestamp tolerance, event dedupe, transition policy, no charge creation in OPS-07. |
| `OPS-07-DF-09` | Telegram webhook → identity/chat binding → action compiler → application service/outbox | chat ID, command, private data | Provider secret channel, update dedupe, allowlisted private chat, confirmation binding, prompt/tool isolation, no raw secrets. |
| `OPS-07-DF-10` | WhatsApp webhook → signature verification → consent/suppression → lead/help flow/outbox | phone, message text, consent | Raw-body HMAC verification, message dedupe, encrypted values, STOP/START precedence, public-facts-only until authorized link. |
| `OPS-07-DF-11` | Vimeo/content event → signed publication contract → content projection | provider refs, media state | Authenticated internal envelope, timestamp/nonce/delivery ID, URL allowlist, no playback link leakage, revoke/correct sequence. |
| `OPS-07-DF-12` | Zoom event or protected launch → class state/launch reference | meeting ID, join URL, passcode | Provider authenticity, timestamp/replay control, opaque target reference, entitlement/role recheck at use. |
| `OPS-07-DF-13` | Support bridge/helper → preview/triage → approved support action | child free text, private question, contact data | Minimize/redact, explicit confirmation, authenticated bridge, bounded retention, no auto-send during OPS-07, prompt injection resistance. |
| `OPS-07-DF-14` | Attachment/archive/remote URL → validator → parser/index | file content, metadata, embedded URLs | Size/type/magic limits, archive/path defenses, sandbox, SSRF defense, redirect/DNS revalidation, content quarantine. |
| `OPS-07-DF-15` | Application events → logs/metrics/analytics/evidence/support export | all classes by accident | Structured allowlist, redaction before serialization, no request bodies/secrets/targets, scan fixtures and generated artifacts. |
| `OPS-07-DF-16` | Consent/suppression/retention/deletion/export request → policy/state machine → stores/providers | D2/D3/D6 | Versioned consent, suppression at claim and dispatch, deletion/export authorization, retention clock, audit without payload, provider tombstone/reconciliation seam. |
| `OPS-07-DF-17` | Social-approved event → draft/approval → provider command | content revisions, destinations | Exact-revision approval, private/learner flags denied, command dedupe, no destination token leakage, correction/retraction confirmation. |

## Abuse cases that must be demonstrated

- Identifier substitution, body/route mismatch, stale session, disabled membership, sibling enumeration, and cross-product joins.
- Replay and race conditions across setup/reset, recovery code, idempotency, webhooks, entitlement transitions, deletion, and suppression.
- Raw URL/passcode/token disclosure through DTO, error, redirect, `Location`, log, metric label, trace, screenshot, snapshot, audit, and export.
- Archive traversal, decompression exhaustion, polyglot MIME, remote URL redirect to private address, DNS rebinding, and oversized streaming response.
- Prompt injection that requests secrets, cross-learner data, unsupported external sourcing, tool invocation, or system-prompt disclosure.
