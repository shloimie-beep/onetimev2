# OPS-07 — Dynamic integration-candidate resolution

## Purpose

The repository state observed while this packet was generated contains an accepted OT-60R → OT-80 → OT-81 → OT-82 → OT-83 lineage plus several later feature leaves. No single observed pull request contains all later provider/content heads. Codex must therefore resolve the current candidate from live Git history and explicit repository control records; it must not use timestamps or pull-request numbers as authority.

## Observed immutable anchors

| Lane | PR | Branch | Observed SHA | Relationship |
|---|---:|---|---|---|
| OT-60R recovery convergence | 17 | `codex/ot60r-recovery-convergence` | `dfef7de2035e08f1ee72e0133ccf656fe7a74444` | accepted convergence ancestor |
| OT-80 final convergence | 23 | `codex/ot80-one-shot-final-convergence` | `741af0c08ee1d43be4e220b7c6e4c77a2330adc2` | accepted convergence ancestor |
| OT-81 Day-One certification | 24 | `codex/ot81-dayone-certification-staging` | `ff23c9af0c3e3de18cd991097eb6e66032b11546` | accepted certification ancestor of OT-82 |
| OT-82 brand system foundation | 26 | `codex/ot82-brand-system-foundation` | `a8e4109b0530855bc7a5f56c90104706b9c8cd7c` | accepted ancestor of OT-83 |
| OT-83 household and portal foundation | 27 | `codex/ot83-household-portals-foundation` | `a02d1d254ae0d17804fb657079a7871567260ea2` | latest shared product base observed |
| OT-84 Telegram action gateway | 29 | `codex/ot84-telegram-action-gateway` | `f98103ecc3660dbda871a91485656e17580940a8` | parallel OT-83 leaf |
| OT-85 WhatsApp lead assistant | 28 | `codex/ot85-whatsapp-lead-assistant` | `fb6b3266e2bb2689fdfc1f751764fd98ecca8f0a` | parallel OT-83 leaf |
| OT-87 Stripe TEST entitlements | 30 | `codex/ot87-stripe-test-entitlements` | `6ecb680713a2fd5cd7bc03766fe9b8974c9b75df` | parallel OT-83 leaf |
| OT-86A Vimeo content and KB | 31 | `codex/ot86a-vimeo-content-kb` | `87a1bb7ffd6a2fa0d016a1831894d430aa2ee065` | parallel OT-83 leaf and OT-86B base |
| OT-86B social publishing | 32 | `codex/ot86b-buffer-social` | `97fa0c91758888f4e9de0af17d70002a0124669f` | stacked descendant of OT-86A |


## Required algorithm

Run from a clean clone of `webcraft-media/onetimev2` with no production credentials loaded.

```bash
set -euo pipefail
git fetch --all --prune --tags
git status --short
git remote -v
git show origin/main:ops/execution/control/CANONICAL-CANDIDATE.json 2>/dev/null || true
git for-each-ref --sort=-committerdate --format='%(refname) %(objectname) %(committerdate:iso8601)' refs/remotes/origin
git log --all --decorate --oneline --graph --max-count=300
```

1. Build a candidate set from the default branch, the live `ops/execution/control/CANONICAL-CANDIDATE.json`, open integration/convergence/release branches, and any newer branch whose commit message or run-state record explicitly declares an integrated candidate.
2. Resolve every candidate to a full 40-character commit SHA. Record branch, SHA, commit time, parent SHAs, pull-request URL when available, control-file status, and all `ops/codex-runs/**/BASE-RESOLUTION.json` or equivalent records.
3. Verify ancestry with `git merge-base --is-ancestor` rather than branch names. The accepted lineage anchors are the OT-80, OT-81, OT-82, and OT-83 SHAs in the table above.
4. For each current product capability that is in release scope, verify ancestry of its feature head. At packet generation, the relevant later heads were OT-84, OT-85, OT-87, OT-86A, and OT-86B. OT-86B already includes OT-86A; it does not include OT-84, OT-85, or OT-87.
5. Inspect migration order, app composition, package exports, route registration, worker startup, and run-state declarations. A commit that contains files copied from a lane but is not an ancestor of that lane requires an explicit conflict/disposition record and equivalent test evidence.
6. Classify the result exactly as one of:
   - `FULLY_INTEGRATED`: a single authoritative ref contains every release-scoped lane and passes ancestry/equivalence checks.
   - `AUTHORITATIVE_PARTIAL`: an explicit current control record names a smaller release scope and records every excluded lane as out of scope. This is auditable but is not sufficient for a final all-capability OPS-07 corrective branch.
   - `NO_INTEGRATED_CANDIDATE`: no authoritative single ref satisfies the release scope.
   - `AMBIGUOUS_CANDIDATE`: two or more refs make conflicting authority claims and no repository record resolves them.
7. Write the result to `ops/codex-runs/OPS-07/OPS-07-58746abd/BASE-RESOLUTION.json` and validate it before any edit.
8. Create `codex/ops-07-security-privacy-corrective-58746abd` only when the classification is `FULLY_INTEGRATED`. Use the exact selected SHA as the branch point. Never merge parallel lanes merely to make OPS-07 proceed.
9. For `AUTHORITATIVE_PARTIAL`, `NO_INTEGRATED_CANDIDATE`, or `AMBIGUOUS_CANDIDATE`, complete the read-only audit and severity report, set run status to `BLOCKED_CANDIDATE_RESOLUTION`, and make no source edit.

## Required evidence fields

`BASE-RESOLUTION.json` must contain `task_id`, `packet_id`, `captured_at_utc`, `repository`, `default_branch_sha`, `candidate_classification`, `selected_ref`, `selected_sha`, `selection_reasons`, `rejected_candidates`, `ancestry_checks`, `release_scope`, `included_lanes`, `excluded_lanes`, `control_records`, `working_tree_clean`, and `no_production_credentials_loaded`.

No field may contain a symbolic SHA, abbreviated SHA, unresolved variable, or prose such as “latest.”
