# OPS-07 — Synthetic fixture and harness contract

## Fixture rules

- Use reserved documentation domains, RFC example addresses, opaque UUIDs, and synthetic names that cannot be confused with real users.
- Never copy production rows, provider payloads, credentials, phone numbers, child questions, support tickets, media links, or passcodes.
- Provider secrets are random per test process and are never committed.
- Raw-body fixtures contain no real account, chat, phone, customer, meeting, or media identifier.
- Database fixtures cover at least two accounts, two products per account, two households, three learners in one household, a sibling pair, a support-only guardian, revoked/disabled memberships, archived/deleted/suppressed contacts, and conflicting identity records.
- All time-based tests use an injected clock. All network tests route to local mock endpoints with outbound networking denied.

## PostgreSQL race harness

For each race, create barriers so transactions reach the critical section together, record transaction IDs and isolation levels, and assert the final invariant after both commit/rollback results are known. Required races:

1. Active learner limit create/restore.
2. One student user to two learners.
3. Two student users to one learner.
4. Recovery-code double use.
5. Same idempotency key/same and different payload.
6. Same optimistic version update.
7. Login-rate-limit budget across two processes.
8. Provider event replay and out-of-order delivery.
9. Suppression/consent revocation against outbox claim/dispatch.
10. Deletion/export and deletion/outbox races.

## Prohibited-data scanner dictionary

Seed the synthetic run with unique canary values for each prohibited class, then assert those canaries do not appear outside their authorized storage cells. Categories:

- session/CSRF/MFA/recovery/provider secret canary;
- raw join/playback/provider URL/passcode canary;
- email/phone/contact-note canary;
- learner name/question/support-text canary;
- private content/source canary.

Scan text and JSON artifacts, stdout/stderr, logs, traces, metrics, screenshots metadata, browser storage, requested URLs, response headers, exports, and built bundles. A canary match fails gate `OPS-07-G7`; do not redact the evidence after the fact and call it a pass.

## Prompt-injection corpus

Include direct, indirect retrieval, tool-output, encoded, Unicode/bidi, multi-turn, cross-learner, source-fabrication, system-prompt, secret-exfiltration, and unrestricted-network attempts. Expected output is a policy-safe refusal/abstention or a grounded authorized answer with allowlisted source references. The harness must inspect tool calls and retrieval filters, not only final text.
