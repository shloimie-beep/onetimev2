# OPS-07 — One Time Security and Learner-Privacy Red-Team Packet Factory

Act as a principal application security, privacy, and authorization engineer. TASK_ID is `OPS-07`; use it everywhere.

Generate a direct-to-Codex packet for a final security/privacy review and corrective branch against the integrated One Time candidate. Audit implementation and prior OT-24/OT-26/OT-34/OT-38 findings read-only; do not edit GitHub yourself.

The Codex prompt must persist state before edits, dynamically select the current integration candidate, reproduce findings, implement scoped fixes, and prove:

- account/product/role/household/guardian/learner isolation at query and service layers;
- student session resolves to one learner with no sibling enumeration or inference;
- parent reset/suspend without secret retrieval or student impersonation;
- owner/admin real memberships, privileged MFA/session rotation/revocation/recovery protections;
- CSRF, secure cookies, no-store private data, return-route safety, rate limits, idempotency, optimistic concurrency, audit;
- signup/CRM duplicate and identity conflict integrity;
- webhook signatures/timestamps/nonces/replay protection for Stripe TEST, Telegram, WhatsApp, Vimeo/content, Zoom, and support bridge;
- no raw provider links/passcodes/tokens, secrets, contact data, child free text, or private questions in logs/analytics/support exports;
- attachment/content ingestion validation, archive/path abuse defense, SSRF/URL allowlisting, size/type limits;
- prompt/tool injection protection for Telegram helpers, student KB helper, WhatsApp lead bot, and support triage;
- knowledge-base answers restricted to authorized Rabbi content and learner scope, with no invented external sourcing;
- consent/version/retention/deletion/export seams and suppression enforcement;
- CSP/security headers/dependency/secret scans and safe error behavior.

Require adversarial negative tests, disposable PostgreSQL concurrency/isolation, browser role tests, and a severity/owner/disposition report. Do not weaken product functionality or mark missing credentials as security success. No production access, exploit against external services, real-user testing, sends, charges, deploy, or DNS mutation.

## Delivery protocol

Try queue branch `dropoff/ops-07-<packetid8>`, path `packets/OPS-07/<packet-id>/`, PR `[OPS-07][PACKET READY] Security and privacy red team`; require real URL+SHA. Otherwise create exactly `OPS-07-CODEX-PACKET.zip` in Library and return one link. No loose prose.

Include packet manifest, Codex prompt, threat model/data flows, authorization and negative-test matrices, remediation gates, evidence schema, and checksums. No unresolved placeholders.

