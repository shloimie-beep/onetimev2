# OPS-07 — Direct-to-Codex security and learner-privacy packet

Packet ID: `OPS-07-58746abd`  
Generated UTC: `2026-07-16T04:11:54Z`  
Target: `webcraft-media/onetimev2`  
Corrective branch to create only after candidate resolution: `codex/ops-07-security-privacy-corrective-58746abd`

This packet is the single ZIP fallback required by the OPS-07 delivery protocol. The packet factory performed read-only GitHub inspection and made no product changes. The queue branch and pull request were not fabricated because this environment cannot create a real commit SHA or pull-request URL.

## Execution order

1. Read `OPS-07-FACTORY-DIRECTIVE.md` and `OPS-07-CODEX-PROMPT.md` completely.
2. Apply `OPS-07-CANDIDATE-RESOLUTION.md` before creating a worktree or branch.
3. Persist the run state required by `OPS-07-EXECUTION-STATE-SCHEMA.json` before any source edit.
4. Reproduce prior and preliminary findings using `OPS-07-READONLY-AUDIT-BASELINE.md`.
5. Use the threat model, authorization matrix, and adversarial test matrix as mandatory scope.
6. Apply only compatibility-preserving fixes supported by reproduced evidence.
7. Satisfy every remediation gate, validate the evidence objects, generate the severity/owner/disposition report, and verify `OPS-07-CHECKSUMS.sha256`.

## Non-negotiable result semantics

- A missing credential, unavailable provider, absent database, or unavailable browser is `BLOCKED_ENVIRONMENTAL`, never `PASS`.
- A parallel feature leaf is not an integrated candidate merely because it is newer.
- No severity S0 or S1 finding may be deferred or accepted without explicit human security-owner approval recorded outside this packet.
- No production resource, external user, real message, charge, deployment, DNS record, or provider configuration may be touched.
- Product behavior may not be weakened to make a security test pass.
