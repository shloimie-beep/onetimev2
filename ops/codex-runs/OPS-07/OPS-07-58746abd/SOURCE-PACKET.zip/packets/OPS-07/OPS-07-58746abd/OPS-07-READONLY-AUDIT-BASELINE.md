# OPS-07 — Read-only audit baseline and reproduction register

Generated UTC: `2026-07-16T04:11:54Z`. These observations are review inputs, not substitutes for reproduction on the dynamically selected candidate.

## Prior-finding sources

| Source | Immutable reference | Use in OPS-07 |
|---|---|---|
| OT-24 PR2 hardening gate | `ops/evidence/ot-24/PR2-HARDENING-GATE.md` as present at `97fa0c91758888f4e9de0af17d70002a0124669f` | Reproduce all 15 findings; do not assume later closure. |
| OT-25/OT-26 intake addendum | `ops/evidence/ot-36/OT-25-OT-26-ADDENDUM.md` as present at `97fa0c91758888f4e9de0af17d70002a0124669f` | Reproduce delivery scoping, consent/suppression, expiry, and no-raw-target requirements. |
| OT-34 hardening report | `ops/evidence/ot-34/HARDENING-REPORT.md` at `87f9b315c54e32e918912cc100610e2c561b68ac` | Compare security behavior only; do not import the superseded migration/model. |
| OT-38 final report | `ops/evidence/ot-38/FINAL-REPORT.md` at `245649523566a7a0ace493ba70ede2a405ebdcce` | Compare MFA/session/return-route behavior only; do not import the superseded migration/model. |
| OT-60R supersession matrix | `ops/evidence/ot-60r/SUPERSESSION-MATRIX.md` on the accepted lineage | Preserve the canonical model and the narrow HMAC login-CSRF port decision. |

## OT-24 register

| ID | Original issue | OPS-07 reproduction requirement | Packet-generation observation |
|---|---|---|---|
| OT24-01 | MFA was readiness metadata, not verified second factor | Owner/admin password-only access, factor enrollment, challenge, replay, recovery, replacement, disablement, session assurance, and revocation tests | Real TOTP/recovery code exists in the OT-83 lineage; recent re-authentication for factor replacement/revocation must be reproduced. |
| OT24-02 | Authenticated write CSRF accepted cookie-only proof | Header/body proof required; cookie-only, missing, mismatched, cross-session, stale, and replayed proof fail before service invocation | Current portal and core write routes appear to require an explicit submitted token. Reproduce every mounted write route. |
| OT24-03 | Login throttling was process-local | Multi-process and restart-persistent PostgreSQL rate-limit proof; atomic concurrency; bounded retry metadata | Current auth code uses durable budget storage. Reproduce with two app instances and disposable PostgreSQL. |
| OT24-04 | Nonexistent account skipped password verification | Constant-work dummy-hash path and response/timing distribution tests | Current auth code uses a dummy Argon2 hash. Reproduce without logging identifiers. |
| OT24-05 | Login/auth-sensitive responses lacked no-store | HTML, JSON, redirects, errors, MFA, portal, CRM, content, billing, and exports must be private/no-store | Current routes set no-store in several paths. Enumerate every private route and error branch. |
| OT24-06 | CRM cursor was unsigned and unbound | Tamper, expiry, version, account, product, filter, sort, limit, and principal binding | Confirmed in observed OT-83 source: cursor encoding is plain base64url JSON and decode accepts untrusted values without a MAC or context binding. |
| OT24-07 | Assignee lacked same-scope membership enforcement | Create/update/filter/list/detail joins must require active account/product membership and permitted role | Confirmed in observed OT-83 source: list/detail joins use `users.user_key = contacts.assigned_user_key` without account/product/status predicates. |
| OT24-08 | Manual contacts defaulted to outreach without consent | Manual create defaults to no-send/no-reminder and suppression until versioned consent exists | Confirmed in observed OT-83 source: manual create inserts `reminder_preference='email'` and `suppression_state='active'`. |
| OT24-09 | Idempotency key was not bound to request hash | Same key/same canonical payload replays; same key/different payload conflicts atomically | Reproduce public lead, CRM create/update, portal mutations, provider inboxes, and support actions. |
| OT24-10 | Reused key could return a wrong previous response | Mismatched replay never returns a prior body and creates no side effect | Reproduce with concurrent requests and transaction rollback proof. |
| OT24-11 | Shared phone/different email could 500 | Deterministic privacy-safe conflict, no contact identifier disclosure, no partial rows | Reproduce public signup and CRM paths under concurrency. |
| OT24-12 | Leading-zero number was forced to one country | Explicit E.164 or approved locale parsing only; ambiguous values rejected with safe validation | Reproduce international matrix and WhatsApp normalization consistency. |
| OT24-13 | Public signup could reopen archived contacts and overwrite CRM fields | Explicit policy, field ownership, consent/suppression preservation, audit, no silent reactivation | Reproduce archived, deleted, suppressed, and identity-conflict states. |
| OT24-14 | Performance evidence was not throttled-mobile p75 | Keep security tests independent; measure browser p75 only where a product claim depends on it | Do not waive security gates because local performance smoke tests pass. |
| OT24-15 | Touch-target proof used height OR width | Both dimensions or documented exception; role/browser security flows remain usable | Include in browser gate because unusable security controls are ineffective. |

## OT-26 delivery and privacy register

1. Re-read account, product, audience, classification, consent version, channel preference, suppression, contact status, occurrence status, and `deliver_by` immediately before claim and immediately before external dispatch.
2. Scope every contact/signup/household/learner join by account and product.
3. Never claim provider-mode rows from a sink worker, unknown/future event kinds, or unsupported channels.
4. Never send after expiry. Record a stable redacted skip reason.
5. Family and School messages remain distinct; School output never contains class access, join action, member access, payment, or reminder language.
6. Raw provider targets, class URLs, passcodes, tokens, message bodies, contact values, and child data never enter outbox JSON, logs, audits, analytics, screenshots, fixtures, or support exports.
7. Missing recurring-producer evidence remains a product blocker; a green dispatcher processing zero rows is not success.

## Preliminary candidate findings to reproduce first

| Finding | Preliminary severity | Evidence path observed | Required disposition |
|---|---|---|---|
| `OPS-07-PRELIM-001` | S1 | Several CRM/class/content domain calls are scoped by application configuration rather than an authenticated principal passed from route to service to SQL. | Prove single-tenant deployment invariant or implement principal-bound account/product/membership enforcement at every layer. |
| `OPS-07-PRELIM-002` | S1 | Manual CRM create defaults to active email outreach without recorded consent. | Reproduce, then default to suppressed/no-reminder and prove no outbox eligibility. |
| `OPS-07-PRELIM-003` | S2 | CRM cursor is unsigned base64url JSON and is not bound to account/product/principal/query context. | Reproduce tampering and cross-context reuse, then sign/version/expire/bind. |
| `OPS-07-PRELIM-004` | S1 | CRM assignee joins and lookup paths are not consistently scoped to active account/product membership. | Reproduce cross-scope and disabled-user cases, then enforce in write and read SQL. |
| `OPS-07-PRELIM-005` | S1 | Privileged MFA recovery-code replacement and factor revocation appear to require only an existing session plus CSRF, with no explicit recent step-up. | Require recent MFA/password proof, rotate/revoke session families, and test stolen-session scenarios. |
| `OPS-07-PRELIM-006` | S2 | Return-route validation rejects external/API/backslash values but does not visibly reject a login loop. | Reproduce `/login`, encoded login, nested return parameters, fragments, and canonicalization bypasses. |
| `OPS-07-PRELIM-007` | S1 | Student resolution orders active identity links and selects the first row. A database partial unique index exists, but service behavior under corruption is not fail-closed. | Prove uniqueness under real PostgreSQL concurrency and make resolver reject zero or more than one active subject. |
| `OPS-07-PRELIM-008` | S1 | Parent/student support preview preserves submitted body text in a preview object. | Prove child free text is minimized, redacted, retention-bound, and excluded from logs/analytics/exports unless explicitly authorized. |
| `OPS-07-PRELIM-009` | S1 | OT-84, OT-85, OT-87, and OT-86A/B were observed as parallel or stacked leaves, not one integrated candidate. | Candidate resolution must fail closed unless a newer authoritative integration exists. |

Every preliminary finding must end as `fixed`, `not_reproduced` with counter-evidence, or `blocked_environmental`. `Not inspected` is not an allowed final disposition.
