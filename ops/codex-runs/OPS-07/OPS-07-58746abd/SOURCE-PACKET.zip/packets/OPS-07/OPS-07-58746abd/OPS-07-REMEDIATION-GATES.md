# OPS-07 — Remediation gates

A gate passes only when all listed evidence exists on the selected candidate plus the OPS-07 corrective commit. A blocked tool or credential is not a pass. Severity S0/S1 findings block the final ready disposition unless fixed or explicitly approved by a named human security owner in a repository record created outside automated output.

| Gate | Required pass criteria | Blocking result |
|---|---|---|
| `OPS-07-G0` Candidate and state | `FULLY_INTEGRATED`; clean worktree; exact SHA; state persisted before edits; no production credentials; packet checksum verified | `BLOCKED_CANDIDATE_RESOLUTION` or `FAILED_STATE_DISCIPLINE` |
| `OPS-07-G1` Account/product/membership/role isolation | Authenticated principal propagated route→service→SQL; active real membership; every query/mutation scoped; direct repository negative tests; no cross-scope inference | `FAILED_AUTHORIZATION_ISOLATION` |
| `OPS-07-G2` Household/guardian/learner isolation | Active guardian relationship; household predicate; exactly-one student subject; sibling/corruption/concurrency tests; parent reset/suspend/revoke without secret or impersonation | `FAILED_LEARNER_PRIVACY` |
| `OPS-07-G3` Privileged authentication | Real MFA; short pre-auth; replay-safe TOTP/recovery; recent step-up for factor management; session rotation/revocation/security-version; recovery protections | `FAILED_PRIVILEGED_AUTH` |
| `OPS-07-G4` Request and mutation integrity | Explicit CSRF; secure cookies; private no-store; safe return routes; durable rate limits; request-bound idempotency; optimistic concurrency; redacted durable audit | `FAILED_REQUEST_INTEGRITY` |
| `OPS-07-G5` Signup/CRM identity integrity | Canonical identities; safe duplicate conflicts; no silent archived/deleted reactivation; consent/suppression-safe manual create; signed bound cursor; scoped assignees | `FAILED_IDENTITY_INTEGRITY` |
| `OPS-07-G6` Provider ingress and replay | Local raw-byte verification fixtures; freshness; nonce/update/event/delivery dedupe; state-machine order; TEST-only Stripe; no external calls; missing credentials reported blocked | `FAILED_PROVIDER_TRUST` |
| `OPS-07-G7` Sensitive-data containment | Mechanical scans of source, DB fixtures, logs, metrics, traces, analytics, browser storage/network, screenshots, evidence, support exports, and bundles show no prohibited raw data | `FAILED_DATA_CONTAINMENT` |
| `OPS-07-G8` Attachment/content ingestion | Type/magic/size/count/depth/ratio limits; traversal/link defenses; parser sandbox; SSRF/redirect/DNS/IP allowlist; transactional quarantine | `FAILED_INGESTION_SECURITY` |
| `OPS-07-G9` Prompt/tool/KB safety | Authorization before retrieval; approved Rabbi corpus only; grounded source refs; abstention; prompt/tool injection corpus; least-privilege tools; no external sourcing invention | `FAILED_AI_SAFETY` |
| `OPS-07-G10` Privacy lifecycle | Versioned consent; suppression at claim/dispatch; retention jobs; deletion/export authorization and concurrency; provider/manual-required seams; no raw child text in durable sinks | `FAILED_PRIVACY_LIFECYCLE` |
| `OPS-07-G11` Platform hardening | CSP and security headers; safe errors; body limits; dependency/SBOM audit; repository/history/build secret scans; source-map/bundle review | `FAILED_PLATFORM_HARDENING` |
| `OPS-07-G12` PostgreSQL and browser proof | Fresh and upgrade migrations on disposable PostgreSQL; multi-connection races; isolation tests; Playwright role/storage/network/bfcache tests; all artifacts hashed | `FAILED_ASSURANCE` |
| `OPS-07-G13` Finding closure and report | Every prior/preliminary/new finding has severity, owner, reproduction, root cause, affected surfaces, fix, tests, residual risk, and disposition; no unowned blocker | `FAILED_REPORTING` |

## Scoped-fix rules

1. Do not wholesale merge OT-34 or OT-38. Preserve the current canonical schema and implement only behaviorally required compatible changes.
2. Do not remove or disable product capability to satisfy a security test. Place unsafe provider actions behind an explicit unavailable state only when the provider is genuinely unconfigured, while local verification still runs.
3. Prefer defense in depth: route capability, service authorization, SQL predicates, schema constraints, transaction locks, and output schemas.
4. Every migration is additive or has a documented reversible transition. Run fresh, upgrade, checksum, idempotency, and rollback/readback evidence.
5. Security fixes that alter public error behavior, cookies, session lifetime, consent, or delivery eligibility require focused browser and regression tests.
6. A finding marked `not_reproduced` must include the exact command/test, candidate SHA, counter-evidence, and why the prior evidence no longer applies.
